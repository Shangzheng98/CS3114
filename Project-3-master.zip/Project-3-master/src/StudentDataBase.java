
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Shangzheng Ji
 * @author Ruichang Chen
 * @version 11/7/2019
 *          the default student manager
 */
public class StudentDataBase {
    private ArrayList<Student> students;
    private RandomAccessFile raf;

    /**
     * the constructor with a file name
     *
     * @param input
     *            the file name
     */
    public StudentDataBase(String input) throws Exception {
        this.students = new ArrayList<>();
        raf = new RandomAccessFile(input, "r");
    }


    /**
     * load the student information from file to student manager
     *
     * @throws IOException
     *             if the file not exist
     */
    public void loadStudentData() throws IOException {
        byte[] header = new byte[10];
        raf.read(header);
        int studentSize = raf.readInt();
        String divider = "GOHOKIES";
        for (int i = 0; i < studentSize; i++) {
            long pid = raf.readLong();
            String strPID = Long.toString(pid);
            for (int k = strPID.length(); k < 9; k++) {
                strPID = "0" + strPID;
            }
            String firstName;
            //String middleName;
            String lastName;
            byte temp = raf.readByte();
            StringBuilder stringBuilder = new StringBuilder();
            while ((char)temp != '$') {
                stringBuilder.append((char)temp);
                temp = raf.readByte();
            }
            firstName = stringBuilder.toString();
            stringBuilder = new StringBuilder();
            temp = raf.readByte();
            while ((char)temp != '$') {
                stringBuilder.append((char)temp);
                temp = raf.readByte();
            }
            //middleName = stringBuilder.toString();
            // get last name
            stringBuilder = new StringBuilder();
            temp = raf.readByte();
            while ((char)temp != '$') {
                stringBuilder.append((char)temp);
                temp = raf.readByte();
            }
            lastName = stringBuilder.toString();
            Student temp2 = new Student(strPID, new Name(firstName, lastName));
            students.add(temp2);
            for (int j = 0; j < 8; j++) {
                if ((char)raf.readByte() != divider.getBytes()[j]) {
                    System.out.println("end of section indicator error");
                    System.exit(-1);
                }
            }
        }
        raf.close();
    }


    /**
     * get students list
     *
     * @return the student list
     */
    public List getStudents() {
        return this.students;
    }


    /**
     * get student
     * @param pid the pid
     * @return the student
     */
    public Student getStudent(String pid) {
        for (Student student : students) {
            if (student.getPid().equals(pid)) {
                return student;
            }
        }
        return null;

    }
}
