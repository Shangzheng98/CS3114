import java.util.*;

/**
 * the heap class
 *
 * @param <T>
 *            the generic type;
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
class MaxHeap<T extends Comparable> {
    private T[] heap; // Pointer to the heap array
    private int size; // Maximum size of the heap
    private int n; // Number of things now in heap

    /**
     * Constructor supporting preloading of heap contents
     *
     * @param h
     *            the input array
     * @param num
     *            the number in the input array
     * @param max
     *            the capacity of heap
     */
    public MaxHeap(T[] h, int num, int max) {
        heap = h;
        n = num;
        size = max;
        buildheap();
    }

    // Return


    /**
     * return current size of the heap
     *
     * @return current size of the heap
     */
    public int heapsize() {
        return n;
    }


    /**
     * Return true if pos a leaf position, false otherwise
     *
     * @param pos
     *            position of array
     * @return if the position is a leaf
     */
    public boolean isLeaf(int pos) {
        return (pos >= n / 2) && (pos < n);
    }


    /**
     * Return position for left child of pos
     *
     * @param pos
     *            position of array
     * @return if the position is leftchild
     */
    public int leftchild(int pos) {
        if (pos >= n / 2) {

            return -1;
        }
        return 2 * pos + 1;
    }


    /**
     * Return position for right child of pos
     *
     * @param pos
     *            postion of array
     * @return if the position is rightChild
     */
    public int rightchild(int pos) {
        if (pos >= (n - 1) / 2) {
            return -1;
        }
        return 2 * pos + 2;
    }


    /**
     * Return position for parent
     *
     * @param pos
     *            postion of array
     * @return if the position is parent
     */
    public int parent(int pos) {
        if (pos <= 0) {
            return -1;
        }
        return (pos - 1) / 2;
    }


    /**
     * Insert val into heap
     *
     * @param key
     *            the val
     */
    public void insert(T key) {
        if (n >= size) {
            System.out.println("Heap is full");
            return;
        }
        int curr = n++;
        heap[curr] = key; // Start at end of heap
        // Now sift up until curr's parent's key > curr's key
        while ((curr != 0) && (heap[curr].compareTo(heap[parent(curr)]) > 0)) {
            swap(heap, curr, parent(curr));
            curr = parent(curr);
        }
    }


    /**
     * Heapify contents of Heap
     */
    private void buildheap() {
        for (int i = n / 2 - 1; i >= 0; i--) {
            siftdown(i);
        }
    }


    /**
     * Put element in its correct place
     *
     * @param pos
     *            the position
     */
    private void siftdown(int pos) {
        if ((pos < 0) || (pos >= n)) {
            return; // Illegal position
        }
        while (!isLeaf(pos)) {
            int j = leftchild(pos);
            if ((j < (n - 1)) && (heap[j].compareTo(heap[j + 1]) < 0)) {
                j++; // j is now index of child with greater value
            }
            if (heap[pos].compareTo(heap[j]) >= 0) {
                return;
            }
            swap(heap, pos, j);
            pos = j; // Move down
        }
    }


    /**
     * Remove and return maximum value
     *
     * @return
     *            the max element
     * @throws Exception
     *            the file is not found
     */
    public T removemax() throws Exception {
        if (n == 0) {
            throw new Exception("the heap is empty"); // Removing from empty
        }
        // heap
        swap(heap, 0, --n); // Swap maximum with last value
        siftdown(0); // Put new heap root val in correct place
        return heap[n];
    }


    /**
     * Remove and return element at specified position
     *
     * @param pos
     *            the position
     * @return
     *            the element at that position
     * @throws Exception
     *             illegal heap position
     */
    public T remove(int pos) throws Exception {
        if ((pos < 0) || (pos >= n)) {
            throw new Exception("illegal heap position");
        } // Illegal heap
        // position
        if (pos == (n - 1)) {
            n--;
        } // Last element, no work to be done
        else {
            swap(heap, pos, --n); // Swap with last value
            update(pos);
        }
        return heap[n];
    }


    /**
     * Modify the value at the given position
     *
     * @param pos
     *            the position
     * @param newVal
     *            the input value
     */
    public void modify(int pos, T newVal) {
        if ((pos < 0) || (pos >= n)) {
            return;
        } // Illegal heap position
        heap[pos] = newVal;
        update(pos);
    }


    /**
     * The value at pos has been changed, restore the heap property
     *
     * @param pos
     *            the position
     */
    private void update(int pos) {
        // If it is a big value, push it up
        while ((pos > 0) && (heap[pos].compareTo(heap[parent(pos)]) > 0)) {
            swap(heap, pos, parent(pos));
            pos = parent(pos);
        }
        siftdown(pos); // If it is little, push down
    }


    /**
     * swap two value
     *
     * @param c
     *            heap arry
     * @param fpos
     *            front position
     * @param spos
     *            back position
     */
    public void swap(Comparable[] c, int fpos, int spos) {
        Comparable tmp = c[fpos];
        c[fpos] = c[spos];
        c[spos] = tmp;
    }

}
