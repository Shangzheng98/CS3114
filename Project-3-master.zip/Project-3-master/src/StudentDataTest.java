import java.io.IOException;
import java.util.List;

/**
 * the student Data Test class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
public class StudentDataTest extends student.TestCase {
    private StudentDataBase sb;

    /**
     * setUp before test
     * @throws Exception the file is not found
     */
    public void setUp() throws Exception {
        sb = new StudentDataBase("sample_vtstudents.data");
    }


    /**
     * test database
     *
     * @throws IOException
     *             connot find file
     */
    public void test() throws IOException {
        List sts = sb.getStudents();
        assertEquals(sts.size(), 0);
        sb.loadStudentData();
        sb.getStudents();
        assertNull(sb.getStudent("ssss"));
        assertNotNull(sb.getStudent("465830040"));

    }
}
