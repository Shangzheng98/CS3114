/**
 * the student class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
public class Student implements Comparable {
    private String pid;
    private double score;
    private Name name;

    /**
     * the constructor of student
     *
     * @param p
     *            pid
     * @param s
     *            score
     * @param n
     *            the name
     */
    public Student(String p, double s, Name n) {
        this.pid = p;
        this.score = s;
        this.name = n;
    }


    /**
     * the constructor of student
     *
     * @param p
     *            pid
     * @param n
     *            name
     */
    public Student(String p, Name n) {
        this.pid = p;
        this.name = n;
    }


    /**
     * getter method to pid
     *
     * @return the pid
     */
    public String getPid() {
        return this.pid;
    }


    /**
     * getter method to get name
     *
     * @return the name
     */
    public Name getName() {
        return this.name;
    }


    /**
     * getter method to get score
     *
     * @return the score
     */
    public double getScore() {
        return this.score;
    }


    /**
     * compare two store
     *
     * @param o
     *            the object
     * @return 1 larger -1 small 0 equal
     */
    @Override
    public int compareTo(Object o) {
        if (o instanceof Student) {
            return Double.compare(this.getScore(), ((Student)o).getScore());
        }
        else {
            throw new ClassCastException("Something comparable is expected.");
        }
    }
}
