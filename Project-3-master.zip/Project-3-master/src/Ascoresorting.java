import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

/**
 * the main class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 * 
 */

public class Ascoresorting {
    /**
     * the entry of program
     *
     * @param args
     *            the passed in arguments
     * @throws Exception
     *             the file not find
     */
    public static void main(String[] args) throws Exception {
        HeapSort heapSort = new HeapSort(args[0]);
        heapSort.run();
        heapSort.multiWayMerge();
        StudentDataBase studentDataBase = new StudentDataBase(args[1]);
        studentDataBase.loadStudentData();
        RandomAccessFile randomAccessFile = new RandomAccessFile(args[0], "r");
        byte[] bytes = new byte[(int)randomAccessFile.length()];
        int recordCount = randomAccessFile.read(bytes) / 16;
        ByteBuffer input = ByteBuffer.wrap(bytes);
        int outputCount = 0;
        for (int i = 1; i <= recordCount; i++) {
            if (outputCount == 100) {
                break;
            }
            long pid = input.getLong();
            double score = input.getDouble();
            if (pid / 1000000000 == 909) {
                String spid = Long.toString(pid);
                spid = spid.substring(3);
                Student student = studentDataBase.getStudent(spid);
                if (student != null) {
                    System.out.println(pid + ", " + student.getName()
                        + " at rank " + i + " with Ascore " + score);
                    outputCount++;
                }
            }
        }
    }
}
