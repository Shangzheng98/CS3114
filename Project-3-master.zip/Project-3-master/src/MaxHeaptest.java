/**
 * the heap test class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
public class MaxHeaptest extends student.TestCase {
    private MaxHeap<Student> h;
    private Student[] st;

    /**
     * run befor test
     */
    public void setUp() {
        st = new Student[10];
        st[0] = new Student("99999", 90, new Name("sss", "ddd"));
        st[1] = new Student("199999", 10, new Name("sss", "ddd"));
        st[2] = new Student("19999", 30, new Name("sss", "ddd"));

    }


    /**
     * test heap
     *
     * @throws Exception
     *             illegal position in heap
     */
    public void test() throws Exception {
        h = new MaxHeap<>(st, 3, 10);
        assertEquals(h.heapsize(), 3);
        while (h.heapsize() != 0) {
            assertEquals(h.removemax().getScore(), 90, -1);
            assertEquals(h.removemax().getScore(), 30, -1);
            assertEquals(h.removemax().getScore(), 10, -1);
        }
        Student s1 = new Student("1999999", 100, new Name("sss", "ddd"));
        Student s2 = new Student("1993333", 50, new Name("rerer", "sdsds"));
        Student s3 = new Student("1993333", 40, new Name("ssds", "dsd"));
        try {
            s1.compareTo(h);
        }
        catch (Exception e) {
            System.out.println("catched");
        }
        h.insert(s1);
        h.insert(s2);
        h.insert(s3);
        h.insert(s1);
        h.insert(s2);
        h.insert(s3);
        h.insert(s1);
        h.insert(s2);
        h.insert(s3);
        h.insert(s1);

        assertEquals(-1, h.parent(-1));
        assertEquals(h.leftchild(0), 1);
        assertEquals(h.rightchild(0), 2);
        assertEquals(h.leftchild(9), -1);
        assertEquals(h.rightchild(9), -1);
        h.modify(1, s2);
        h.modify(-1, s2);
        h.modify(11, s2);
        h.insert(s2);

        try {
            h.remove(-1);
        }
        catch (Exception e)
        {
            System.out.println("catched");
        }


        assertEquals(100.0, st[0].getScore(), -1);
        assertEquals(-1, s2.compareTo(s1));
        assertEquals(1, s2.compareTo(s3));
        assertEquals(1, s1.compareTo(s2));
        System.out.println(s1.getName().toString());

    }


    /**
     * test remove
     */
    public void test1() {
        h = new MaxHeap(st, 3, 10);
        assertEquals(h.heapsize(), 3);

        Student s1 = new Student("1999999", 100, new Name("sss", "ddd"));
        Student s2 = new Student("1993333", 50, new Name("rerer", "sdsds"));
        Student s3 = new Student("1993333", 40, new Name("ssds", "dsd"));
        h.insert(s1);
        h.insert(s2);
        h.insert(s3);
        try {
            assertEquals(h.removemax().getScore(), 100, -1);
            assertEquals(h.removemax().getScore(), 90, -1);
            assertEquals(h.removemax().getScore(), 50, -1);
            assertEquals(h.removemax().getScore(), 40, -1);
            assertEquals(h.removemax().getScore(), 30, -1);
            assertEquals(h.removemax().getScore(), 10, -1);

        }
        catch (Exception e) {
            System.out.println("fail");
        }

    }
}
