/**
 * the name class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
public class Name {
    private String firstName;
    private String lastName;

    /**
     * the constructor of name
     *
     * @param fn
     *            first name
     * @param ln
     *            last name
     */
    public Name(String fn, String ln) {
        this.firstName = fn;
        this.lastName = ln;
    }


    /**
     * getter method to get first name
     *
     * @return the firstname
     */
    public String getFirstName() {
        return this.firstName;
    }


    /**
     * getter method to get last name
     *
     * @return the lastname
     */
    public String getLastName() {
        return this.lastName;
    }


    /**
     * to string
     *
     * @return the string version name
     */
    public String toString() {
        return getFirstName() + " " + getLastName();
    }
}
