
/**
 * the heap sort test class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
public class HeapSortTest extends student.TestCase {

    /**
     * run before test
     */
    public void setUp() {
        // to do nothing
    }


    /**
     * test multi
     * 
     * @throws Exception
     *             file not found
     */
    public void testMulti() throws Exception {
        HeapSort hs = new HeapSort("sample1k2.bin");
        hs.run();
        assertEquals(0, hs.multiWayMerge());
    }


    /**
     * test multi1
     * 
     * @throws Exception
     *             file not found
     */
    public void testMulti1() throws Exception {
        HeapSort.MultiWayHeap multiWayHeap = new HeapSort.MultiWayHeap(
            "sample1k2.bin", 8192, 0);
        for (int i = 0; i < 1024; i++) {
            System.out.println(multiWayHeap.getMax());
            multiWayHeap.popMax();
        }
        assertNotNull(multiWayHeap);
    }
}
