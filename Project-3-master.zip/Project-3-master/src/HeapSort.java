import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.io.File;

/**
 * the heap sort class
 *
 * @author shangzheng Ji
 * @author Ruichang Chen
 * @version 11/11/2019
 */
public class HeapSort {
    /**
     * the buffersize is 1024
     */
    final static int BUFFERSIZE = 1024;
    private ArrayList<Integer> records;
    private String fileName;

    /**
     * the constrictor of heapsort
     *
     * @param fn
     *            the input file
     * @throws Exception
     *             the file doesnt exist
     */
    public HeapSort(String fn) throws Exception {
        fileName = fn;
        records = new ArrayList<>();
    }


    /**
     * run file
     *
     * @throws Exception
     *             the file doesnt exist or out of EOF
     */
    public void run() throws Exception {
        OutputBuffer outputBuffer = new OutputBuffer("temp.bin");
        Record[] heapBuffer = new Record[8 * BUFFERSIZE];
        InputBuffer inputBuffer = new InputBuffer(fileName);
        Record record = inputBuffer.pop();
        int count = 0;
        while (record != null) {
            if (count < BUFFERSIZE * 8) {
                heapBuffer[count] = record;
                count++;
            }
            if (count == BUFFERSIZE * 8) {
                MaxHeap<Record> heap = new MaxHeap<>(heapBuffer, count, 8
                    * BUFFERSIZE);

                while (heap.heapsize() != 0) {
                    Record record1 = heap.removemax();
                    outputBuffer.push(record1);
                }
                outputBuffer.flush();
                records.add(count);
                count = 0;
                record = inputBuffer.pop();
                continue;
            }
            record = inputBuffer.pop();
            if (record == null) {
                MaxHeap<Record> heap = new MaxHeap<>(heapBuffer, count, 8
                    * BUFFERSIZE);
                while (heap.heapsize() != 0) {
                    outputBuffer.push(heap.removemax());
                }
                outputBuffer.flush();
                records.add(count);
                count = 0;
            }
        }
        outputBuffer.close();
        inputBuffer.close();
        File file = new File(fileName);
        if (!file.delete()) {
            System.out.println("Error deleting file");
        }
        file = new File("temp.bin");
        File newName = new File(fileName);
        if (!file.renameTo(newName)) {
            System.out.println("Error renaming file");
        }
    }


    /**
     * multiway merge
     * @return  the process finished
     * @throws Exception
     *             the file is not found
     */
    public int multiWayMerge() throws Exception {
        while (records.size() > 8) {
            // System.out.println(records);
            OutputBuffer outputBuffer = new OutputBuffer("temp.bin");
            ArrayList<Integer> temp = new ArrayList<>();
            int count = 0;
            int fileOffset = 0;
            while (records.size() - count >= 8) {
                // get the block size and push to new temp arrayList
                int totalRecord = 0;
                ArrayList<MultiWayHeap> multiWayHeaps = new ArrayList<>();
                for (int i = count; i < count + 8; i++) {
                    multiWayHeaps.add(new MultiWayHeap(fileName, records.get(i),
                        fileOffset));
                    fileOffset += records.get(i);
                    totalRecord += records.get(i);
                }
                temp.add(totalRecord);
                // start sorting

                while (true) {
                    int maxIndex = -1;
                    double max = -1;
                    for (int i = 0; i < 8; i++) {
                        if (multiWayHeaps.get(i).getMax() != null
                            && multiWayHeaps.get(i).getMax().score > max) {
                            maxIndex = i;
                            max = multiWayHeaps.get(i).getMax().score;
                        }
                    }
                    if (maxIndex == -1) {
                        break;
                    }
                    else {
                        outputBuffer.push(multiWayHeaps.get(maxIndex).popMax());
                    }
                }
                count += 8;
                for (int i = 0; i < 8; i++) {
                    multiWayHeaps.get(i).close();
                }
            }
            outputBuffer.flush();
            outputBuffer.close();

            File file = new File(fileName);
            if (!file.delete()) {
                System.out.println("Error deleting file");
            }
            file = new File("temp.bin");
            File newName = new File(fileName);
            if (!file.renameTo(newName)) {
                System.out.println("Error renaming file");
            }
            records = temp;
        }
        // System.out.println(records);
        int count = records.size();
        int totalCount = 0;
        ArrayList<MultiWayHeap> multiWayHeaps = new ArrayList<>();
        OutputBuffer outputBuffer = new OutputBuffer("temp.bin");
        for (int i = 0; i < count; i++) {
            multiWayHeaps.add(new MultiWayHeap(fileName, records.get(i),
                totalCount));
            totalCount += records.get(i);
        }
        while (true) {
            int maxIndex = -1;
            double max = -1;
            for (int i = 0; i < count; i++) {
                if (multiWayHeaps.get(i).getMax() != null && multiWayHeaps.get(
                    i).getMax().score > max) {
                    maxIndex = i;
                    max = multiWayHeaps.get(i).getMax().score;
                }
            }
            if (maxIndex == -1) {
                break;
            }
            else {
                outputBuffer.push(multiWayHeaps.get(maxIndex).popMax());
            }
        }
        for (int i = 0; i < count; i++) {
            multiWayHeaps.get(i).close();
        }
        outputBuffer.flush();
        outputBuffer.close();
        File file = new File(fileName);
        if (!file.delete()) {
            System.out.println("Error deleting file");
        }
        file = new File("temp.bin");
        File newName = new File(fileName);
        if (!file.renameTo(newName)) {
            System.out.println("Error renaming file");
        }
        return 0;
    }

    /**
     * the record class
     *
     * @author shangzheng Ji
     * @author Ruichang Chen
     * @version 11/11/2019
     */
    public static class Record implements Comparable {
        private long pid;
        private double score;
        private int runNumber;

        /**
         * record constructor t
         *
         * @param p
         *            pid
         * @param s
         *            score
         */
        public Record(long p, double s) {
            this.pid = p;
            this.score = s;
            runNumber = -1;
        }


        /**
         * compare to method
         *
         * @param o
         *            the object to compare
         * @return 1 larger -1 smaller 0 equal
         */
        @Override
        public int compareTo(Object o) {
            if (o instanceof Record) {
                return Double.compare(this.score, ((Record)o).score);
            }
            else {
                throw new ClassCastException(
                    "Something comparable is expected.");
            }
        }


        /**
         * to string
         *
         * @return the string version record
         */
        public String toString() {
            return this.pid + " " + this.score;
        }


        /**
         * setter number
         *
         * @param num
         *            the input number
         */
        public void setRunNumber(int num) {
            this.runNumber = num;
        }


        /**
         * get run NUmber
         *
         * @return the run number
         */
        public int getRunNumber() {
            return this.runNumber;
        }
    }


    /**
     * the outputer buffer class
     *
     * @author shangzheng Ji
     * @author Ruichang Chen
     * @version 11/11/2019
     */
    public static class OutputBuffer {
        private ByteBuffer outputByte;
        private RandomAccessFile output;
        private int currentSize;

        /**
         * the constructor of outerbuffer
         *
         * @param fileName
         *            the input file
         * @throws Exception
         *             the file doesnt exist
         */
        public OutputBuffer(String fileName) throws Exception {
            output = new RandomAccessFile(fileName, "rw");
            outputByte = ByteBuffer.allocate(BUFFERSIZE * 16);
            currentSize = 0;
        }


        /**
         * put record to outputbuffer
         *
         * @param record
         *            the input record
         * @throws Exception
         *             the output file doesnt exist
         */
        public void push(Record record) throws Exception {
            outputByte.putLong(record.pid);
            outputByte.putDouble(record.score);
            currentSize++;
            if (currentSize == 1023) {
                flush();
            }
        }


        /**
         * close output file
         *
         * @throws IOException
         *             the file doesnt exist
         */
        public void close() throws IOException {
            output.close();
        }


        /**
         * write into file
         *
         * @throws Exception
         *             thefile donesnt exist
         */
        public void flush() throws Exception {
            byte[] bytes = outputByte.array();
            byte[] out = new byte[currentSize * 16];
            if (currentSize * 16 >= 0) {
                System.arraycopy(bytes, 0, out, 0, currentSize * 16);
            }
            output.write(out);
            outputByte.clear();
            currentSize = 0;
        }
    }


    /**
     * the input buffer test class
     *
     * @author shangzheng Ji
     * @author Ruichang Chen
     * @version 11/11/2019
     */
    public static class InputBuffer {
        private ByteBuffer inputByte;
        private RandomAccessFile input;
        private int currentSize;
        private boolean empty;

        /**
         * the constructor of inputbuffer
         *
         * @param fileName
         *            the input file
         * @throws Exception
         *             the file not exist
         */
        public InputBuffer(String fileName) throws Exception {
            input = new RandomAccessFile(fileName, "rw");
            currentSize = 1;
            empty = false;
        }


        /**
         * pop a record from input buffer
         *
         * @return ther poped record
         * @throws Exception
         *             the file out of EOF or the fiele doesnt exist
         */
        public Record pop() throws Exception {
            if (currentSize == 1) {
                byte[] bytes = new byte[BUFFERSIZE * 16];
                long read = input.read(bytes);
                currentSize = (int)(read / 16);
                inputByte = ByteBuffer.wrap(bytes);
                if (currentSize == 0) {
                    empty = true;
                    return null;
                }
            }
            else {
                currentSize--;
            }
            return new Record(inputByte.getLong(), inputByte.getDouble());
        }


        /**
         * the inputbuffer is emplty
         *
         * @return if empty
         */
        public boolean empty() {
            return empty;
        }


        /**
         * close file
         * 
         * @throws Exception
         *             throw exception
         */
        public void close() throws Exception {
            input.close();
        }
    }


    /**
     * the multi way merge class
     *
     * @author shangzheng Ji
     * @author Ruichang Chen
     * @version 11/11/2019
     */
    static public class MultiWayHeap {
        private int recordCount;
        private int currentCount;
        private int readCount;
        private long fileOffset;
        private Record[] records;
        private MaxHeap<Record> heap;
        private RandomAccessFile file;

        /**
         * the constructor
         * 
         * @param fileName
         *            file name
         * @param rc
         *            count
         * @param fc
         *            offset
         * @throws Exception
         *             file is not found
         */

        public MultiWayHeap(String fileName, int rc, int fc) throws Exception {
            this.recordCount = rc;
            this.currentCount = 0;
            this.readCount = 0;
            this.fileOffset = fc;
            file = new RandomAccessFile(fileName, "r");
            file.seek(fileOffset * 16);
            records = null;
            heap = null;
        }


        /**
         * read block
         * 
         * @throws Exception
         *             the exception
         */
        private void readBlock() throws Exception {
            if (recordCount - readCount >= 1024) {
                records = new Record[BUFFERSIZE * 16];
                byte[] bytes = new byte[BUFFERSIZE * 16];
                file.read(bytes);
                readCount += 1024;
                ByteBuffer buffer = ByteBuffer.wrap(bytes);
                for (int i = 0; i < 1024; i++) {
                    Record record = new Record(buffer.getLong(), buffer
                        .getDouble());
                    records[i] = record;
                }
                heap = new MaxHeap<>(records, 1024, 1024);
            }
            else {
                int recordToRead = recordCount - readCount;
                records = new Record[recordToRead * 16];
                byte[] bytes = new byte[recordToRead * 16];
                file.read(bytes);
                readCount += recordToRead;
                ByteBuffer buffer = ByteBuffer.wrap(bytes);
                for (int i = 0; i < recordToRead; i++) {
                    Record record = new Record(buffer.getLong(), buffer
                        .getDouble());
                    records[i] = record;
                }
                heap = new MaxHeap<>(records, recordToRead, recordToRead);
                readCount += recordToRead;
            }
        }


        /**
         * get max
         * 
         * @return the max
         * @throws Exception
         *             file not found
         */
        public Record getMax() throws Exception {
            if (currentCount == recordCount) {
                return null;
            }
            if (heap == null || heap.heapsize() == 0) {
                readBlock();
            }
            return records[0];
        }


        /**
         * pop max
         * 
         * @return the max number
         * @throws Exception
         *             throw excption
         */
        public Record popMax() throws Exception {
            currentCount++;
            return heap.removemax();
        }


        /**
         * close file
         * 
         * @throws Exception
         *             the file is not found
         */
        public void close() throws Exception {
            file.close();
        }
    }
}
