import java.io.File;
import student.TestCase;

/**
 * Test file processor
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class FileProcesserTest extends TestCase {
    private FileProcesser f;

    /**
     * setup for test case
     */
    public void setUp() {
        f = new FileProcesser();
    }

    /**
     * test read command
     */
    public void test() {
        File input = new File("input.txt");
        assertEquals(f.readCommand(input), 0);
    }

}
