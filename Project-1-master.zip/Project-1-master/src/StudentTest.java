import student.TestCase;

/**
 * test case for student class
 * 
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class StudentTest extends TestCase {
    private Student s1;


    /**
     * setup for test case
     */
    public void setUp() {
        s1 = new Student(90, "ss", "ls", 1001, "c");
    }


    /**
     * test set function
     */
    public void testSetfunction() {
        s1.setFirstName("new");
        assertEquals("new", s1.getFirstName());
        s1.setId(10002);
        assertEquals(10002, s1.getId());
        s1.setLastName("sssss");
        assertEquals("sssss", s1.getLastName());
        s1.setScore(100);
        assertEquals(100, s1.getScore());

    }
}
