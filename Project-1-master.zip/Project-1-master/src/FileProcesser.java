import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * File Processer class
 * This class read instruction from file and process it
 * 
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class FileProcesser {
    private ArrayList<Section> sections;
    private int currentSection;


    /**
     * generate the output string with section and student id
     * 
     * @param section
     *            section number
     * @param studentId
     *            student id
     * @return formatted string of section and student id
     */
    private String getSectionIdString(int section, int studentId) {
        String sSection = "";
        String sId = "";
        sSection += String.valueOf(section / 10);
        sSection += String.valueOf(section % 10);
        sId += String.valueOf(studentId / 1000);
        sId += String.valueOf(studentId / 100);
        sId += String.valueOf(studentId / 10);
        sId += String.valueOf(studentId % 10);
        return sSection + sId;
    }


    /**
     * Default constructor for Fileprocesser
     */
    public FileProcesser() {
        this.currentSection = 1;
        sections = new ArrayList<Section>();
        Section section1 = new Section(1);
        Section section2 = new Section(2);
        Section section3 = new Section(3);
        sections.add(section1);
        sections.add(section2);
        sections.add(section3);

    }


    /**
     * Get current section number
     * 
     * @return current section
     */
    public ArrayList<Section> getSections() {
        return this.sections;
    }


    /**
     * swap first name and last name
     * 
     * @param str
     *            name divided with white space
     * @return swapped name
     */
    public String nameSwap(String str) {
        String[] s = str.split("\\s+");
        s[0] = s[0] + s[1];
        s[1] = s[0].substring(0, s[0].length() - s[1].length());
        s[0] = s[0].substring(s[1].length());
        return s[0] + " " + s[1];
    }


    /**
     * format the name in same cases
     * 
     * @param name
     *            name of student
     * @return formatted name of student
     */
    public String captureName(String name) {
        name = name.substring(0, 1).toUpperCase() + name.substring(1)
            .toLowerCase();
        return name;
    }


    /**
     * switch section
     * 
     * @param num
     *            number of section need to be switched
     */
    public void switchSection(int num) {
        this.currentSection = num;
        for (int i = 0; i < this.sections.size(); i++) {
            if (this.getSections().get(i).getId() == num) {
                return;
            }
        }
        Section section2 = new Section(num);
        sections.add(section2);

    }


    /**
     * remove section
     * 
     * @param num
     *            number of section to be removed
     */
    public void removeSection(int num) {
        if (this.getSections() != null && this.getSections().get(num
            - 1) != null) {
            this.sections.get(num - 1).getBst().clear();
            this.sections.get(num - 1).resetStudentId();
        }

    }


    /**
     * read command from file
     * 
     * @param input
     *            file
     * @return 0 if no error
     */
    public int readCommand(File input) {

        Scanner scanner = null;
        try {
            scanner = new Scanner(input);
        }
        catch (FileNotFoundException e) {
            System.out.println("Students file not found. Exiting...");
        }

        String line = null;
        String currentStudent = null;
        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            line = line.trim();
            if (!line.equals("")) {
                String[] store = line.split("\\s+");
                if (!store[0].equals("score")) {
                    currentStudent = null;
                }
                if (store[0].equals("dumpsection")) {
                    sections.get(currentSection - 1).dumpsection();
                }
                else if (store[0].equals("insert")) {
                    String fstName = this.captureName(store[1]);
                    String lstName = this.captureName(store[2]);
                    int id = sections.get(currentSection - 1).getStudentId();
                    Student student = new Student(0, store[1], store[2], id,
                        "F");
                    currentStudent = lstName + " " + fstName;
                    sections.get(currentSection - 1).insert(currentStudent,
                        student);

                }
                else if (store[0].equals("score")) {
                    if (currentStudent == null) {
                        System.out.println("score command can only be called"
                            + " after an insert command or a"
                            + " successful search command with"
                            + " one exact output.");
                    }
                    else {
                        sections.get(currentSection - 1).score(currentStudent,
                            Integer.parseInt(store[1]));
                    }
                }

                else if (store[0].equals("section")) {

                    this.switchSection(Integer.parseInt(store[1]));
                    System.out.println("switch to section " + Integer.parseInt(
                        store[1]));
                }
                else if (store[0].equals("search")) {
                    if (store.length == 3) {
                        String name = this.nameSwap(this.captureName(store[1])
                            + " " + this.captureName(store[2]));

                        Student temp = sections.get(currentSection - 1).search(
                            name);
                        if (temp == null) {
                            System.out.println("Search failed. Student "
                                + store[1] + " " + store[2]
                                + " doesn't exist in section "
                                + this.currentSection);
                        }
                        else {
                            System.out.println("Found " + getSectionIdString(
                                this.currentSection, temp.getId()) + ", " + this
                                    .captureName(store[1]) + " " + this
                                        .captureName(store[2]) + ", score = "
                                + temp.getScore());
                            currentStudent = name;
                        }
                    }
                    else {
                        String name = this.captureName(store[1]);
                        ArrayList<Student> temp = sections.get(currentSection
                            - 1).searchAll(name);
                        System.out.println("search results for " + store[1]
                            + ":");
                        if (temp == null || temp.isEmpty()) {
                            System.out.println(store[1]
                                + " was found in 0 records in section "
                                + this.currentSection);
                        }
                        else {
                            for (int i = 0; i < temp.size(); i++) {
                                System.out.println(getSectionIdString(
                                    this.currentSection, temp.get(i).getId())
                                    + ", " + temp.get(i).getFirstName() + " "
                                    + temp.get(i).getLastName() + ", score = "
                                    + temp.get(i).getScore());
                            }
                            System.out.println(store[1] + " was found in "
                                + temp.size() + " records in section "
                                + this.currentSection);
                            if (temp.size() == 1) {
                                currentStudent = temp.get(0).getLastName() + " "
                                    + temp.get(0).getFirstName();
                            }
                            else {
                                currentStudent = null;
                            }
                        }
                    }
                }
                else if (store[0].equals("remove")) {
                    if (store.length != 3) {
                        continue;
                    }
                    String name = this.nameSwap(this.captureName(store[1]) + " "
                        + this.captureName(store[2]));
                    Student temp = this.sections.get(currentSection - 1)
                        .getBst().find(name);
                    if (temp == null) {
                        System.out.println("Remove failed. Student " + store[1]
                            + " " + store[2] + " doesn't exist in section "
                            + this.currentSection);
                    }
                    if (this.sections.get(currentSection - 1).remove(name)) {
                        System.out.println("Student " + store[1] + " "
                            + store[2] + " get removed from section "
                            + this.currentSection);
                    }
                }
                else if (store[0].equals("removesection")) {
                    if (store.length == 2 && store[1] != null) {
                        this.removeSection(Integer.parseInt(store[1]));
                        System.out.println("Section " + store[1] + " removed");
                    }
                    else {
                        this.removeSection(this.currentSection);
                        System.out.println("Section " + this.currentSection
                            + " removed");
                    }
                }
                else if (store[0].equals("grade")) {
                    if (this.getSections().get(currentSection - 1) != null) {
                        this.sections.get(currentSection - 1).grade();
                    }
                }
                else if (store[0].equals("findpair")) {

                    ArrayList<String> temp;
                    if (store.length == 2) {
                        System.out.println(
                            "Students with score difference less than or equal "
                                + store[1] + ":");
                        temp = this.sections.get(currentSection - 1).findPair(
                            Integer.parseInt(store[1]));
                    }
                    else {
                        System.out.println(
                            "Students with score difference less than or equal "
                                + 0 + ":");
                        temp = this.sections.get(currentSection - 1).findPair(
                            0);
                    }
                    for (int i = 0; i < temp.size(); i++) {
                        System.out.println(temp.get(i));
                    }

                    System.out.println("found " + temp.size() + " pairs");
                }
            }
        }

        scanner.close();
        return 0;
    }

}
