
import java.util.ArrayList;
import java.util.Iterator;
import student.TestCase;

/**
 * test case for BST
 * 
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class BSTtest extends TestCase {

    private BST<Integer, Integer> bst;


    /**
     * Setup test for BST
     */
    public void setUp() {
        bst = new BST<Integer, Integer>();
        bst.insert(1, 2);
        bst.insert(2, 2);
        bst.insert(3, 1);
        bst.insert(4, 2);
    }


    /**
     * Test insert for BST
     */
    public void testInsert() {

        bst.insert(5, 1);
        bst.insert(6, 6);
        bst.insert(7, 5);
        bst.insert(8, 3);

        bst.insert(9, 3);
        bst.insert(10, 3);
        bst.insert(5, 4);

        assertEquals(11, bst.size());

    }


    /**
     * test remove for BST
     */
    public void testRemove() {
        assertEquals(4, bst.size());
        int i = bst.remove(1);
        assertEquals(2, i);
        assertEquals(3, bst.size());
        bst.clear();
        assertFalse(bst.contain(40));
        assertEquals(0, bst.size());
        assertNull(bst.remove(1));
        bst.insert(5, 1);
        bst.insert(6, 6);
        bst.insert(7, 5);
        bst.insert(8, 3);

        bst.insert(9, 3);
        bst.insert(10, 3);
        bst.insert(5, 4);
        bst.insert(5, 30);
        bst.insert(5, 10);
        bst.remove(5);
        assertNull(bst.remove(3));
        bst.remove(5);
        bst.remove(6);
        bst.remove(8);
        bst.remove(5);
        bst.remove(5);
        bst.insert(3, 1);
        bst.insert(2, 2);
        bst.insert(1, 2);
        bst.remove(2);
        bst.remove(1);

        assertTrue(bst.contain(3));
        assertFalse(bst.contain(40));

    }


    /**
     * test contain for BST
     */
    public void testContain() {
        assertTrue(bst.contain(1));
        bst.clear();
        bst.insert(1, 2);
        bst.insert(2, 2);
        bst.insert(3, 1);
        bst.insert(4, 2);
    }


    /**
     * test find for BST
     */
    public void testFind() {
        int i = bst.find(1);
        assertEquals(2, i);
    }


    /**
     * Test inorder for BST
     */
    public void testIndorder() {
        bst.clear();
        assertNull(bst.inorderTraversal());

        bst.insert(5, 5);
        bst.insert(11, 11);
        ArrayList<Integer> t = bst.inorderTraversal();
        assertNotNull(t);
        assertEquals(t.size(), 2);
        bst.insert(10, 10);
        bst.insert(9, 9);
        t = bst.inorderTraversal();
        for (int i = 0; i < t.size(); i++) {
            System.out.println(t.get(i));
        }
    }


    /**
     * test Iterator
     */
    public void testIterator() {
        Iterator<Integer> iter = bst.iterator();
        int i = iter.next();
        assertEquals(2, i);
    }
}
