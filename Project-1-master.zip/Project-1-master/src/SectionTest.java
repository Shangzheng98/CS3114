import student.TestCase;

/**
 * test section
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class SectionTest extends TestCase {
    private Section s1;

    /**
     * setup of the test case
     */
    public void setUp() {
        s1 = new Section(1);
    }

    /**
     * test change id of the section
     */
    public void testChangeId() {
        s1.changeId("3");
        assertEquals(s1.getId(), 3);
    }
}
