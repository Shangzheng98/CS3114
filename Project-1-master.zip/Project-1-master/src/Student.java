/**
 * student class
 * store info about student
 * 
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class Student {

    private int score;
    private String firstName;
    private String lastName;
    private int id;
    private String grade;


    /**
     * constructor for student
     * 
     * @param score
     *            student score
     * @param firstName
     *            student first name
     * @param lastName
     *            student last name
     * @param id
     *            student it
     * @param grade
     *            student grade
     */
    public Student(
        int score,
        String firstName,
        String lastName,
        int id,
        String grade) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.grade = grade;
        this.score = score;
        this.id = id;
    }


    /**
     * get student score
     * 
     * @return student score
     */
    public int getScore() {
        return this.score;
    }


    /**
     * set student score
     * 
     * @param score
     *            score to be set
     */
    public void setScore(int score) {
        if (score < 50) {
            this.grade = "F";
        }
        else if (score < 53) {
            this.grade = "D-";
        }
        else if (score < 55) {
            this.grade = "D";
        }
        else if (score < 58) {
            this.grade = "D+";
        }
        else if (score < 60) {
            this.grade = "C-";
        }
        else if (score < 65) {
            this.grade = "C";
        }
        else if (score < 70) {
            this.grade = "C+";
        }
        else if (score < 75) {
            this.grade = "B-";
        }
        else if (score < 80) {
            this.grade = "B";
        }
        else if (score < 85) {
            this.grade = "B+";
        }
        else if (score < 90) {
            this.grade = "A-";
        }
        else {
            this.grade = "A";
        }
        this.score = score;
    }


    /**
     * get student id
     * 
     * @return student id
     */
    public int getId() {
        return this.id;
    }


    /**
     * set student id
     * 
     * @param id
     *            id to be set
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * get student first name
     * 
     * @return first name of student
     */
    public String getFirstName() {
        return this.firstName;
    }


    /**
     * set student first name
     * 
     * @param name
     *            first name of studnet
     */
    public void setFirstName(String name) {
        this.firstName = name;
    }


    /**
     * get last name of student
     * 
     * @return last name of student
     */
    public String getLastName() {
        return this.lastName;
    }


    /**
     * set last name of student
     * 
     * @param name
     *            last name of student
     */
    public void setLastName(String name) {
        this.lastName = name;
    }


    /**
     * get grade for student
     * 
     * @return grade of student
     */
    public String getGrade() {
        return this.grade;
    }

}
