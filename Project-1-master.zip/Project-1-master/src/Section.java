import java.util.ArrayList;
import java.util.Iterator;

/**
 * section class
 * a section use to contain students
 * 
 * @author Ruichang Chen
 * @author Shangzheng Ji
 * @version 09/23/2019
 *
 */
public class Section {
    private BST<String, Student> bst;
    private int id;
    private int studentId;


    /**
     * format section and id to string for output
     * 
     * @param section
     *            section number
     * @param newId
     *            student id
     * @return formatted string for output
     */
    private String getSectionIdString(int section, int newId) {
        String sSection = "";
        String sId = "";
        sSection += String.valueOf(section / 10);
        sSection += String.valueOf(section % 10);
        sId += String.valueOf(newId / 1000);
        sId += String.valueOf(newId / 100);
        sId += String.valueOf(newId / 10);
        sId += String.valueOf(newId % 10);
        return sSection + sId;
    }


    /**
     * constructor for section
     * 
     * @param num
     *            section number
     */
    public Section(int num) {
        this.bst = new BST<String, Student>();
        this.id = num;
        this.studentId = 0;
    }


    /**
     * get current student id
     * 
     * @return current student id
     */
    public int getStudentId() {
        this.studentId++;
        return this.studentId;
    }


    /**
     * reset current student id to 0
     */
    public void resetStudentId() {
        this.studentId = 0;
    }


    /**
     * get BST for current section
     * 
     * @return BST for current section
     */
    public BST<String, Student> getBst() {
        return bst;
    }


    /**
     * get section id
     * 
     * @return section id
     */
    public int getId() {
        return this.id;
    }


    /**
     * change section id
     * 
     * @param num
     *            new id
     */
    public void changeId(String num) {
        this.id = Integer.parseInt(num);
    }


    /**
     * insert new student into section
     * 
     * @param name
     *            name of student
     * @param student
     *            student object
     */
    public void insert(String name, Student student) {
        if (this.getBst().contain(name)) {
            String rowName = student.getFirstName() + " " + student
                .getLastName();
            System.out.println(rowName + " is already in section " + id);
            Student temp = this.getBst().find(name);
            System.out.println(getSectionIdString(this.id, temp.getId()) + ", "
                + temp.getFirstName() + ' ' + temp.getLastName() + ", score = "
                + temp.getScore());
            this.studentId--;
        }
        else {
            this.getBst().insert(name, student);
            System.out.println(student.getFirstName() + " " + student
                .getLastName() + " inserted");
        }
    }


    /**
     * find all student contain the name
     * 
     * @param name
     *            name used to search
     * @return a ArrayList of all matched student
     */
    public ArrayList<Student> searchAll(String name) {

        ArrayList<Student> temp = this.getBst().inorderTraversal();
        ArrayList<Student> r = new ArrayList<Student>();
        if (temp == null) {
            return null;
        }
        for (int i = 0; i < temp.size(); i++) {
            if ((temp.get(i).getFirstName().equals(name) || temp.get(i)
                .getLastName().equals(name))) {
                r.add(temp.get(i));
            }
        }
        return r;
    }


    /**
     * search for one student with full name
     * 
     * @param str
     *            name of student
     * @return student matched
     */
    public Student search(String str) {

        return this.getBst().find(str);
    }


    /**
     * set score for a student
     * 
     * @param name
     *            name of student
     * @param newScore
     *            new score of student
     */
    public void score(String name, int newScore) {
        if (newScore > 100 || newScore < 0) {
            System.out.println("Scores have to be integers in range 0 to 100.");
            return;
        }
        Student student = this.getBst().find(name);
        student.setScore(newScore);
        System.out.println("Update " + student.getFirstName() + ' ' + student
            .getLastName() + " " + "record, " + "score = " + newScore);
    }


    /**
     * remove a student from section
     * 
     * @param name
     *            name of the student
     * @return true if removed
     */
    public boolean remove(String name) {
        if (this.getBst() == null) {
            return false;
        }
        return (this.getBst().remove(name) != null);
    }


    /**
     * dump all student in this section
     */
    public void dumpsection() {
        System.out.println("Section " + id + " dump:");
        if (this.getBst().getRoot() == null || this.getBst() == null) {
            System.out.println("Size = 0");
            return;
        }
        ArrayList<Student> students = this.getBst().inorderTraversal();
        if (students != null) {
            for (int i = 0; i < students.size(); i++) {
                Student temp = students.get(i);
                System.out.println(getSectionIdString(this.getId(), temp
                    .getId()) + ", " + temp.getFirstName() + " " + temp
                        .getLastName() + ", " + "score = " + temp.getScore());
            }
        }

        System.out.println("Size = " + students.size());
    }


    /**
     * get grade info in this section
     */
    public void grade() {
        String[] grades = { "F", "D-", "D", "D+", "C-", "C", "C+", "B-", "B",
            "B+", "A-", "A" };
        System.out.println("grading completed:");
        for (String grade : grades) {
            int count = getNumberOfStudentGrade(grade);
            if (count > 0) {
                System.out.println(count + " students with grade " + grade);
            }
        }
    }


    /**
     * helper function for grade function
     * 
     * @param grade
     *            target grade
     * @return number of student with this grade
     */
    private int getNumberOfStudentGrade(String grade) {
        ArrayList<Student> students = this.getBst().inorderTraversal();
        if (students == null) {
            return 0;
        }
        int num = 0;
        for (Student student : students) {
            if (student.getGrade() == grade) {
                num++;
            }
        }
        return num;
    }


    /**
     * find student pair within a range
     * 
     * @param diff
     *            range of score difference
     * @return list of student pair match the condition
     */
    public ArrayList<String> findPair(int diff) {
        ArrayList<String> n = new ArrayList<String>();
        Iterator<Student> iter = this.bst.iterator();
        while (iter.hasNext()) {
            Student temp1 = iter.next();
            Iterator<Student> iter2 = this.bst.iterator();
            while (iter2.hasNext()) {
                Student temp2 = iter2.next();
                String pair = temp1.getFirstName() + " " + temp1.getLastName()
                    + ", " + temp2.getFirstName() + " " + temp2.getLastName();

                if (temp1.equals(temp2)) {
                    continue;
                }
                else if (Math.abs(temp1.getScore() - temp2.getScore()) <= diff
                    && !n.contains(pair) && !n.contains(temp2.getFirstName()
                        + " " + temp2.getLastName() + ", " + temp1
                            .getFirstName() + " " + temp1.getLastName())) {
                    n.add(pair);
                }
                else {
                    continue;
                }
            }
            iter2 = this.bst.iterator();
        }
        return n;
    }
}
