# Project2 CourseManager2
![UML](https://github.com/Shangzheng98/Project-2/blob/master/UML.jpg "UML digram")
