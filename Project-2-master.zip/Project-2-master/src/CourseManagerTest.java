import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseManagerTest extends student.TestCase{
    private  CourseManager courseManager;
    private StudentManager studentManager;
    public void setUp(){

    }

    public void test() throws Exception {
        CourseManager courseManager = new CourseManager();
        StudentManager studentManager = null;
        File input = new File("ji_SampleInput2.txt");
        Scanner scanner = null;
        try {
            scanner = new Scanner(input);
        }
        catch (FileNotFoundException e) {
            System.out.println(e);
            System.exit(-1);
        }
        String line;
        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            if (line.length() > 0) {
                String[] command = line.split("\\s+");
                if (command[0].equals("loadstudentdata")) {
                    studentManager = new StudentManager(command[1]);
                    try {
                        studentManager.loadStudentData();
                    }
                    catch (IOException e) {
                        System.out.println(e);
                        System.exit(-1);
                    }
                    courseManager.loadStudentManager(studentManager);
                }
                else if(command[0].equals("loadcoursedata")) {
                    try {
                        courseManager.loadCourseData(command[1]);
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else if (command[0].equals("savestudentsdata")) {
                    studentManager.saveStudentData(command[1]);
                }
                else if (command[0].equals("savecoursedata")) {
                    courseManager.saveCourseData(command[1]);
                }

                line = line.toLowerCase().trim();
                command = line.split("\\s+");
                if (command[0].equals("section")) {
                    courseManager.setCurrentSection(Integer.parseInt(command[1]));
                }
                else if (command[0].equals("insert")) {
                    courseManager.insertStudent(command[1], command[2], command[3]);
                }
                else if (command[0].equals("searchid")) {
                    courseManager.searchStudentId(command[1]);
                }
                else if (command[0].equals("search")) {
                    if (command.length == 2) {
                        courseManager.searchStudent(command[1]);
                    }
                    else {
                        courseManager.searchStudent(command[1], command[2]);
                    }
                }
                else if (command[0].equals("score")) {
                    courseManager.scoreStudent(Integer.parseInt(command[1]));
                }
                else if (command[0].equals("remove")) {
                    if (command.length == 2) {
                        courseManager.removeStudent(command[1]);
                    }
                    else {
                        courseManager.removeStudent(command[1], command[2]);
                    }

                }
                else if (command[0].equals("clearsection")) {
                    courseManager.clearSection();
                }
                else if (command[0].equals("dumpsection")) {
                    courseManager.dumpSection();
                }
                else if (command[0].equals("grade")) {
                    courseManager.gradeSection();
                }
                else if (command[0].equals("stat")) {
                    courseManager.statSection();
                }
                else if (command[0].equals("list")) {
                    courseManager.listSection(command[1].toUpperCase());
                }
                else if (command[0].equals("findpair")) {
                    if (command.length == 1) {
                        courseManager.findPairSection();
                    }
                    else {
                        courseManager.findPairSection(Integer.parseInt(command[1]));
                    }
                }
                else if (command[0].equals("merge")) {
                    courseManager.mergeSection();
                }
                else if (command[0].equals("clearcoursedata")) {
                    courseManager.clearCourseData();
                }
            }
        }
        assertEquals(systemOut().getHistory(), "Course Load Failed. You have to load Student Information file first.\n" +
                "ji_students.csv successfully loaded\n" +
                "ji_CS3114 Course has been successfully loaded.\n" +
                "switch to section 1\n" +
                "Section 1 dump:\n" +
                "BST by ID:\n" +
                "020380028, sage forbes, score = 4\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "977159896, naomi cote, score = 97\n" +
                "BST by name:\n" +
                "977159896, naomi cote, score = 97\n" +
                "020380028, sage forbes, score = 4\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "BST by score:\n" +
                "020380028, sage forbes, score = 4\n" +
                "977159896, naomi cote, score = 97\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "Size = 3\n" +
                "naomi cote is already in section 1\n" +
                "sandra duncan is already registered in a different section\n" +
                "aileen ford insertion failed. Wrong student information. ID doesn't exist\n" +
                "caleb foley insertion failed. Wrong student information. ID belongs to another student\n" +
                "aileen ford inserted\n" +
                "Update aileen ford record, score = 91\n" +
                "Found 394691224, aubrey williamson, score = 100\n" +
                "Update aubrey williamson record, score = 100\n" +
                "Search Failed. Couldn't find any student with ID 291935757\n" +
                "score command can only be called after an insert command or a successful search command with one exact output.\n" +
                "Found 239721905, aileen ford, score = 91\n" +
                "search results for mostafa kamel:\n" +
                "mostafa kamel was found in 0 records in section 1\n" +
                "search results for sage forbes:\n" +
                "020380028, sage forbes, score = 4\n" +
                "sage forbes  was found in 1 records in section 1\n" +
                "search results for naomi:\n" +
                "977159896, naomi cote, score = 97\n" +
                "naomi was found in 1 records in section 1\n" +
                "Section 1 dump:\n" +
                "BST by ID:\n" +
                "020380028, sage forbes, score = 4\n" +
                "239721905, aileen ford, score = 91\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "977159896, naomi cote, score = 97\n" +
                "BST by name:\n" +
                "977159896, naomi cote, score = 97\n" +
                "020380028, sage forbes, score = 4\n" +
                "239721905, aileen ford, score = 91\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "BST by score:\n" +
                "020380028, sage forbes, score = 4\n" +
                "239721905, aileen ford, score = 91\n" +
                "977159896, naomi cote, score = 97\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "Size = 4\n" +
                "Remove failed. Student mostafa kamel doesn't exist in section 1\n" +
                "Student naomi cote get removed from section 1\n" +
                "search results for naomi:\n" +
                "naomi was found in 0 records in section 1\n" +
                "Remove failed. Student naomi cote doesn't exist in section 1\n" +
                "switch to section 3\n" +
                "Section 3 dump:\n" +
                "BST by ID:\n" +
                "BST by name:\n" +
                "BST by score:\n" +
                "Size = 0\n" +
                "gloria chavez inserted\n" +
                "Update gloria chavez record, score = 100\n" +
                "grading completed\n" +
                "switch to section 1\n" +
                "grading completed\n" +
                "Statistics of section 1:\n" +
                "2 students with grade A \n" +
                "1 students with grade F \n" +
                "Sections could only be merged to an empty section. Section 1 is not empty.\n" +
                "switch to section 4\n" +
                "All sections merged at section 4\n" +
                "Command insert is not valid for merged sections\n" +
                "grading completed\n" +
                "Statistics of section 4:\n" +
                "3 students with grade A \n" +
                "1 students with grade B \n" +
                "1 students with grade C+\n" +
                "5 students with grade F \n" +
                "Students with grade C* are:\n" +
                "792704751, leroy sherman, score = 65, grade = C+\n" +
                "Found 1 students\n" +
                "switch to section 2\n" +
                "Students with grade C* are:\n" +
                "792704751, leroy sherman, score = 65, grade = C+\n" +
                "Found 1 students\n" +
                "Students with grade F are:\n" +
                "248476061, winter hodge, score = 31, grade = F \n" +
                "256593948, sandra duncan, score = 26, grade = F \n" +
                "291935757, brynne myers, score = 4, grade = F \n" +
                "317397180, nigel gonzales, score = 37, grade = F \n" +
                "Found 4 students\n" +
                "Students with grade C+ are:\n" +
                "792704751, leroy sherman, score = 65, grade = C+\n" +
                "Found 1 students\n" +
                "Students with grade C- are:\n" +
                "Found 0 students\n" +
                "Students with grade C are:\n" +
                "Found 0 students\n" +
                "Student sandra duncan get removed from section 2\n" +
                "Students with score difference less than or equal 10:\n" +
                "winter hodge, nigel gonzales\n" +
                "found 1 pairs\n" +
                "Section 2 dump:\n" +
                "BST by ID:\n" +
                "067964700, fritz hudson, score = 78\n" +
                "248476061, winter hodge, score = 31\n" +
                "291935757, brynne myers, score = 4\n" +
                "317397180, nigel gonzales, score = 37\n" +
                "792704751, leroy sherman, score = 65\n" +
                "BST by name:\n" +
                "317397180, nigel gonzales, score = 37\n" +
                "248476061, winter hodge, score = 31\n" +
                "067964700, fritz hudson, score = 78\n" +
                "291935757, brynne myers, score = 4\n" +
                "792704751, leroy sherman, score = 65\n" +
                "BST by score:\n" +
                "291935757, brynne myers, score = 4\n" +
                "248476061, winter hodge, score = 31\n" +
                "317397180, nigel gonzales, score = 37\n" +
                "792704751, leroy sherman, score = 65\n" +
                "067964700, fritz hudson, score = 78\n" +
                "Size = 5\n" +
                "switch to section 3\n" +
                "Section 3 cleared\n" +
                "switch to section 4\n" +
                "Sections could only be merged to an empty section. Section 4 is not empty.\n" +
                "switch to section 5\n" +
                "All sections merged at section 5\n" +
                "grading completed\n" +
                "Statistics of section 5:\n" +
                "2 students with grade A \n" +
                "1 students with grade B \n" +
                "1 students with grade C+\n" +
                "4 students with grade F \n" +
                "Saved all Students data to ji_mystudents.data\n" +
                "Saved all course data to ji_cs3114course.data\n" +
                "All course data cleared.\n" +
                "switch to section 1\n" +
                "Section 1 dump:\n" +
                "BST by ID:\n" +
                "BST by name:\n" +
                "BST by score:\n" +
                "Size = 0\n" +
                "ji_cs3114course Course has been successfully loaded.\n" +
                "switch to section 1\n" +
                "Section 1 dump:\n" +
                "BST by ID:\n" +
                "020380028, sage forbes, score = 4\n" +
                "239721905, aileen ford, score = 91\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "BST by name:\n" +
                "020380028, sage forbes, score = 4\n" +
                "239721905, aileen ford, score = 91\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "BST by score:\n" +
                "020380028, sage forbes, score = 4\n" +
                "239721905, aileen ford, score = 91\n" +
                "394691224, aubrey williamson, score = 100\n" +
                "Size = 3\n" +
                "ji_CS3114_2 Course has been successfully loaded.\n" +
                "Warning: Student aubrey williamson is not loaded to section 3 since he/she is already enrolled in section 1\n" +
                "switch to section 2\n" +
                "Section 2 dump:\n" +
                "BST by ID:\n" +
                "067964700, fritz hudson, score = 78\n" +
                "248476061, winter hodge, score = 31\n" +
                "256593948, sandra duncan, score = 26\n" +
                "291935757, brynne myers, score = 4\n" +
                "317397180, nigel gonzales, score = 37\n" +
                "792704751, leroy sherman, score = 65\n" +
                "BST by name:\n" +
                "256593948, sandra duncan, score = 26\n" +
                "317397180, nigel gonzales, score = 37\n" +
                "248476061, winter hodge, score = 31\n" +
                "067964700, fritz hudson, score = 78\n" +
                "291935757, brynne myers, score = 4\n" +
                "792704751, leroy sherman, score = 65\n" +
                "BST by score:\n" +
                "291935757, brynne myers, score = 4\n" +
                "256593948, sandra duncan, score = 26\n" +
                "248476061, winter hodge, score = 31\n" +
                "317397180, nigel gonzales, score = 37\n" +
                "792704751, leroy sherman, score = 65\n" +
                "067964700, fritz hudson, score = 78\n" +
                "Size = 6\n" +
                "search results for winter hodge:\n" +
                "248476061, winter hodge, score = 31\n" +
                "winter hodge  was found in 1 records in section 2\n" +
                "Update winter hodge record, score = 40\n");
    }

    public void test1() throws IOException {
        CourseManager courseManager = new CourseManager();
        StudentManager studentManager = new StudentManager("ji_students.csv");
        studentManager.loadStudentData();
        courseManager.loadStudentManager(studentManager);
        courseManager.insertStudent("248476061", "winter", "hodge");
        courseManager.dumpSection();
        courseManager.scoreStudent(30);
        courseManager.searchStudentId("248476061");
        courseManager.scoreStudent(100);
        courseManager.dumpSection();
        courseManager.statSection();
        courseManager.gradeSection();
        courseManager.statSection();
        courseManager.insertStudent("256593948", "sandra", "duncan");
        courseManager.insertStudent("123456789", "winter", "hi");
        courseManager.searchStudent("winter");
        courseManager.scoreStudent(50);
    }

    public void test2() throws Exception {
        CourseManager courseManager = new CourseManager();
        StudentManager studentManager = new StudentManager("ji_students.csv");
        studentManager.loadStudentData();
        courseManager.loadStudentManager(studentManager);
        courseManager.loadCourseData("ji_CS3114_2.data");
        //courseManager.saveCourseData("ji_CS3114_2.data");
        ArrayList<Student> list = studentManager.getStudents().inorderTraversal();
        for (Student student : list) {
            System.out.println(student.getFirstName() + " " + student.getLastName());
            System.out.println(student.getPid());
        }

//        courseManager.insertStudent("248476061", "winter", "hodge");
//        courseManager.scoreStudent(60);
//        courseManager.insertStudent("256593948", "sandra", "duncan");
//        courseManager.scoreStudent(60);
//        courseManager.insertStudent("123456789", "winter", "hi");
//        courseManager.scoreStudent(60);
//        courseManager.searchStudentId("256593948");
//        courseManager.scoreStudent(30);
//        courseManager.searchStudentId("248476061");
//        courseManager.scoreStudent(30);
        courseManager.setCurrentSection(1);
        courseManager.dumpSection();
        courseManager.setCurrentSection(2);
        courseManager.dumpSection();
        courseManager.setCurrentSection(3);
        courseManager.dumpSection();

        System.out.println("Search student");
        courseManager.searchStudent("aubrey", "williamson");
//        courseManager.removeStudent("248476061");
//        courseManager.dumpSection();
    }

    public void test3() throws IOException {
        courseManager = new CourseManager();
        StudentManager studentManager = new StudentManager("ji_students.csv");
        studentManager.loadStudentData();
        courseManager.loadStudentManager(studentManager);
        try {
            courseManager.loadCourseData("CS3114.csv");
        } catch (Exception e) {
            e.printStackTrace();
        }
        courseManager.dumpSection();
        courseManager.setCurrentSection(2);
        courseManager.dumpSection();
        courseManager.setCurrentSection(3);
        courseManager.dumpSection();
        courseManager.saveCourseData("CM_Test.data");
        courseManager.clearCourseData();
        courseManager.setCurrentSection(1);
        try {
            courseManager.loadCourseData("CM_Test.data");
        } catch (Exception e) {
            e.printStackTrace();
        }
        courseManager.dumpSection();
        courseManager.setCurrentSection(2);
        courseManager.dumpSection();
        courseManager.setCurrentSection(3);
        courseManager.dumpSection();
    }

    public void test4() throws IOException {
        courseManager = new CourseManager();
        StudentManager studentManager = new StudentManager("ji_students.csv");
        studentManager.loadStudentData();
        courseManager.loadStudentManager(studentManager);
        try {
            courseManager.loadCourseData("CS3114.csv");
        } catch (Exception e) {
            e.printStackTrace();
        }
        courseManager.searchStudent("sage");
        courseManager.scoreStudent(50);
        courseManager.searchStudent("sage");
        courseManager.dumpSection();
        courseManager.searchStudent("sa");
        courseManager.scoreStudent(50);
        courseManager.searchStudent("sage", "forb");
        courseManager.scoreStudent(15);
        courseManager.searchStudent("sa");
        courseManager.searchStudent("sage", "ji");
        courseManager.scoreStudent(17);
        courseManager.searchStudentId("123123123");
        courseManager.scoreStudent(23);
        courseManager.searchStudentId("123123123");
        courseManager.searchStudentId("123456789");
        courseManager.scoreStudent(27);
        courseManager.searchStudentId("123456789");
        courseManager.dumpSection();
        courseManager.removeStudent("123123123");
        courseManager.dumpSection();
        courseManager.searchStudentId("123123123");
        courseManager.searchStudent("sage");
        courseManager.searchStudent("naomi", "sage");
    }
}