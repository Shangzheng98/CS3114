import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;


public class CourseManager {
    private ArrayList<Section> sectionArrayList;
    private BST<String, Integer> enrolledStudentBST;
    private int currentSection;
    private StudentManager sm;
    private String currentStudent;

    public CourseManager()
    {
        sm = null;
        sectionArrayList = new ArrayList<>();
        enrolledStudentBST = new BST<>();
        currentSection = 1;
        currentStudent = null;
        for (int i = 0; i < 21; i++) {
            sectionArrayList.add(new Section(i));
        }
    }

    public CourseManager(String filename) throws Exception {
        sectionArrayList = new ArrayList<>();
        enrolledStudentBST = new BST<>();
        currentSection = 1;
        currentStudent = null;
        for (int i = 0; i < 21; i++) {
            sectionArrayList.add(new Section(i));
        }
        loadCourseData(filename);
    }

    public void loadStudentManager(StudentManager sm) {
        this.sm = sm;
    }

    public void loadCourseData(String filename) throws Exception {
        if (sm == null) {
            System.out.println("Course Load Failed. You have to load Student Information file first.");
            return;
        }
        String[] fileName = filename.split("\\.");
        System.out.println(fileName[0] + " Course has been successfully loaded.");
        if (fileName[1].equals("csv")) {
            File file = new File(filename);
            Scanner s = null;
            try {
                s = new Scanner(file);
            }
            catch (FileNotFoundException e) {
                System.out.println("Course file not found. Exiting...");
                System.exit(-1);
            }
            String line = null;
            while (s.hasNextLine()) {
                line = s.nextLine();
                String[] studentDetails = line.split("\\s*,\\s*");
                String pid = "";
                if (line.length() == 0) {
                    continue;
                }
                if (studentDetails[1].length() != 9) {
                    for (int i = 0; i < 9 - studentDetails[1].length(); i++) {
                        pid += "0";
                    }
                    pid = pid + studentDetails[1];

                }
                else {
                    pid = studentDetails[1];
                }
                String grade = studentDetails[5];
                if (grade.length() == 1) {
                    grade = grade + " ";
                }
                Student temp = new Student(studentDetails[2].toLowerCase(), "",
                        studentDetails[3].toLowerCase(), pid, grade, Integer.parseInt(studentDetails[4]));
                insertStudent(temp, Integer.parseInt(studentDetails[0]));
            }
            s.close();
        }
        else {
            RandomAccessFile randomFile = new RandomAccessFile(filename, "r");
            String header = "CS3114atVT";
            String endOfSection = "GOHOKIES";
            int numOfSection;
            for (int i = 0; i < 10; i++) {
                byte b = randomFile.readByte();
                if (b != header.getBytes(StandardCharsets.UTF_8)[i]) {
                    System.out.println("File header error");
                    System.exit(-1);
                    return;
                }
            }
            numOfSection = randomFile.readInt();
            //System.out.println("There are " + numOfSection + " sections");
            for(int i = 1; i <= numOfSection; i++) {
                // get number of student
                int numberOfStudent = randomFile.readInt();
                // System.out.println("There are " + numberOfStudent + " students in section " + i);
                for(int j = 0; j < numberOfStudent; j++) {
                    long pid = randomFile.readLong();
                    String firstName;
                    String lastName;
                    int score;
                    String grade;
                    StringBuilder stringBuilder = new StringBuilder();
                    // get first name
                    byte b = randomFile.readByte();
                    while ((char)b != '$') {
                        stringBuilder.append((char)b);
                        b = randomFile.readByte();
                    }
                    firstName = stringBuilder.toString();
                    // get last name
                    stringBuilder = new StringBuilder();
                    b = randomFile.readByte();
                    while ((char)b != '$') {
                        stringBuilder.append((char)b);
                        b = randomFile.readByte();
                    }
                    lastName = stringBuilder.toString();
                    // get score
                    score = randomFile.readInt();
                    // get grade
                    stringBuilder = new StringBuilder();
                    for (int k = 0; k < 2; k++) {
                        stringBuilder.append((char) randomFile.readByte());
                    }
                    grade = stringBuilder.toString();
                    //System.out.println("name: " + firstName + " " + lastName);
                    //System.out.println("score: " + score);
                    //System.out.println("grade: " + grade);
                    String strPID = Long.toString(pid);
                    for (int k = strPID.length(); k < 9; k++) {
                        strPID = "0" + strPID;
                    }
                    Student student = new Student(firstName.toLowerCase(), "", lastName.toLowerCase(), strPID, grade.toUpperCase(), score);
                    insertStudent(student, i);
                }
                for (int j = 0; j < 8; j++) {
                    if ((char) randomFile.readByte() != endOfSection.getBytes(StandardCharsets.UTF_8)[j]) {
                        System.out.println("end of section indicator error");
                        System.exit(-1);
                        return;
                    }
                }
            }
            randomFile.close();
        }
        currentStudent = null;
    }

    public void saveCourseData(String filename){
        try {
            RandomAccessFile randomFile = new RandomAccessFile(filename, "rw");
            randomFile.write("CS3114atVT".getBytes());
            Integer numSection = 1;
            for (int i = 20; i > 0; i--) {
                if (!sectionArrayList.get(i).empty()) {
                    numSection = i;
                    break;
                }
            }
            randomFile.writeInt(numSection);
            for (int i = 1; i < numSection + 1; i++) {
                if (!sectionArrayList.get(i).isMerged()) {
                    ArrayList<Student> list = sectionArrayList.get(i).dumpPidSection();
                    randomFile.writeInt(list.size());
                    for (Student student:list) {
                        randomFile.writeLong(Long.parseLong(student.getPid()));
                        String firstName = student.getFirstName() + "$";
                        String lastName = student.getLastName() + "$";
                        randomFile.write(firstName.getBytes(StandardCharsets.UTF_8));
                        randomFile.write(lastName.getBytes(StandardCharsets.UTF_8));
                        randomFile.writeInt(student.getScore());
                        randomFile.writeByte(student.getGrade().getBytes(StandardCharsets.UTF_8)[0]);
                        randomFile.writeByte(student.getGrade().getBytes(StandardCharsets.UTF_8)[1]);
                    }
                    randomFile.write("GOHOKIES".getBytes());
                }
                else {
                    randomFile.writeInt(0);
                    randomFile.write("GOHOKIES".getBytes());
                }
            }
            randomFile.close();
        }
        catch (IOException e) {
            System.out.println(e);
            System.exit(-1);
        }
        System.out.println("Saved all course data to " + filename);
        currentStudent = null;
    }

    public void insertStudent(String pid, String firstName, String lastName)
    {
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command insert is not valid for merged sections");
            currentStudent = null;
            return;
        }
        BST<String, Student> studentData = sm.getStudents();
        Student s =  studentData.find(pid);
        if (s == null)
        {
            System.out.println(firstName + " "+ lastName+" insertion failed. Wrong student information. ID doesn't exist");
            currentStudent = null;
            return;
        }
        else {
            if (!s.getFirstName().equals(firstName) || !s.getLastName().equals(lastName))
            {
                System.out.println(firstName + " "+ lastName+ " insertion failed. Wrong student information. ID belongs to another student");
                currentStudent = null;
                return;
            }
        }
        if (this.enrolledStudentBST.contain(pid))
        {
            if (this.enrolledStudentBST.find(pid) == currentSection)
            {
                System.out.println(firstName + " "+ lastName +" is already in section "+ currentSection);
            }
            else {
                System.out.println(firstName + " "+ lastName +" is already registered in a different section");
            }
            currentStudent = null;
            return;
        }
        enrolledStudentBST.insert(pid, currentSection);
        sectionArrayList.get(currentSection).insertStudent(s);
        currentStudent = pid;
        System.out.println(firstName + " "+ lastName + " inserted");
    }

    public void searchStudentId(String pid)
    {
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command searchId is not valid for merged sections");
            currentStudent = null;
            return;
        }
        Student r = sectionArrayList.get(currentSection).searchid(pid);
        if (r == null)
        {
            System.out.println("Search Failed. Couldn't find any student with ID " + pid);
            currentStudent = null;
        }
        else
        {
            System.out.println("Found " +pid+ ", " + r.getFirstName() + " "+ r.getLastName()+", score = "+ r.getScore());
            currentStudent = pid;
        }
    }

    public void searchStudent(String firstName, String lastName)
    {
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command search is not valid for merged sections");
            currentStudent = null;
            return;
        }
        ArrayList<Student> list = sectionArrayList.get(currentSection).search(firstName, lastName);
        System.out.println("search results for "+ firstName +" " +lastName + ":");
        if (!list.isEmpty())
        {
            for (Student s : list)
            {
                System.out.println(s.getPid()+", " +s.getFirstName()+" "+s.getLastName()+ ", score = "+ s.getScore());
            }
            System.out.println( firstName +" " +lastName +"  was found in "+ list.size() +" records in section " +currentSection);
        }
        else
        {
            System.out.println(firstName +" " +lastName + " was found in 0 records in section " +currentSection);
        }
        if (list.size() == 1) {
            currentStudent = list.get(0).getPid();
        }
        else {
            currentStudent = null;
        }
    }

    public void insertStudent(Student student, Integer section) throws Exception {
        BST<String, Student> studentData = sm.getStudents();
        Student s =  studentData.find(student.getPid());
        if (s == null)
        {
            System.out.println("Warning: Student " + student.getFirstName() + " " + student.getLastName() + " is not loaded to " +
                    "section " + section + " since he/she doesn't exist in the loaded student " +
                    "records.");
            return;
        }
        else {
            if (!s.getFirstName().equals(student.getFirstName()) || !s.getLastName().equals(student.getLastName()))
            {
                System.out.println("Warning: Student " + student.getFirstName() + " " + student.getLastName() + " is not loaded to " +
                        "section " + section + " since the corresponding pid belongs to another student.");
                return;
            }
        }
        if (this.enrolledStudentBST.contain(student.getPid()))
        {
            if (this.enrolledStudentBST.find(student.getPid()).equals(section))
            {
                sectionArrayList.get(section).setStudentScore(student.getPid(), student.getScore());
            }
            else {
                System.out.println("Warning: Student " + student.getFirstName() + " " + student.getLastName() + " is not loaded to " +
                        "section " + section + " since he/she is already enrolled in section " + enrolledStudentBST.find(student.getPid()));
            }
            return;
        }
        enrolledStudentBST.insert(student.getPid(), section);
        sectionArrayList.get(section).insertStudent(student);
    }


    public void searchStudent(String name)
    {
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command search is not valid for merged sections");
            currentStudent = null;
            return;
        }
        ArrayList<Student> list = sectionArrayList.get(currentSection).search(name.toLowerCase());
        System.out.println("search results for "+ name+":");
        if (!list.isEmpty())
        {
            for (Student s : list)
            {
                System.out.println(s.getPid()+", " +s.getFirstName()+" "+s.getLastName()+", "+ "score = "+ s.getScore());
            }
            System.out.println( name+" was found in "+ list.size() +" records in section " +currentSection);
        }
        else
        {
            System.out.println(name+ " was found in 0 records in section " +currentSection);
        }
        if (list.size() == 1) {
            currentStudent = list.get(0).getPid();
        }
        else {
            currentStudent = null;
        }
    }

    public void setCurrentSection(int sectionId)
    {
        currentSection = sectionId;
        System.out.println("switch to section " + currentSection);
        currentStudent = null;
    }

    public void scoreStudent(int score) {
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command score is not valid for merged sections");
            currentStudent = null;
            return;
        }
        if (score > 100 || score < 0) {
            System.out.println("Scores have to be integers in range 0 to 100.");
        }
        else if (currentStudent == null) {
            System.out.println("score command can only be called after an insert command or a successful " +
                    "search command with one exact output.");
        }
        else {
            sectionArrayList.get(currentSection).setStudentScore(currentStudent, score);
            Student student = sectionArrayList.get(currentSection).searchid(currentStudent);
            System.out.println("Update " + student.getFirstName() + " " + student.getLastName() + " record, score = " + score);
        }
        currentStudent = null;
    }

    public void removeStudent(String pid) {
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command remove is not valid for merged sections");
            currentStudent = null;
            return;
        }
        Student s = sectionArrayList.get(currentSection).searchid(pid);
        if (s == null) {
            System.out.println("Remove failed. couldn't find any student with id " + pid);
        }
        else {
            sectionArrayList.get(currentSection).removeStudent(pid);
            enrolledStudentBST.remove(pid);
            System.out.println("Student " + s.getFirstName() + " "+ s.getLastName()+" get removed from section "+ currentSection);
            currentStudent = null;
        }
    }

    public void removeStudent(String firstName, String lastName) {
        currentStudent = null;
        if (sectionArrayList.get(currentSection).isMerged()) {
            System.out.println("Command search is not valid for merged sections");
            return;
        }
        String name = firstName + " " + lastName;
        ArrayList<Student> list = sectionArrayList.get(currentSection).search(firstName, lastName);
        if (list.size() == 1) {
            sectionArrayList.get(currentSection).removeStudent(list.get(0).getPid());
            enrolledStudentBST.remove(list.get(0).getPid());
            System.out.println("Student " + name + " get removed from section " + currentSection);
        }
        else {
            System.out.println("Remove failed. Student " + name + " doesn't exist in section " + currentSection);
        }
    }

    public boolean clearSection()
    {
        ArrayList<Student> list = sectionArrayList.get(currentSection).dumpPidSection();
        for (Student student:list) {
            enrolledStudentBST.remove(student.getPid());
        }
        sectionArrayList.get(currentSection).clear();
        sectionArrayList.get(currentSection).notMerged();
        System.out.println("Section " + currentSection + " cleared");
        currentStudent = null;
        return true;
    }

    public void dumpSection()
    {
        System.out.println("Section " + currentSection + " dump:");
        System.out.println("BST by ID:");
        ArrayList<Student> idList = sectionArrayList.get(currentSection).dumpPidSection();
        for (Student student : idList) {
            System.out.println(student.getPid() + ", " + student.getFirstName() + " " + student.getLastName() +
                    ", score = " + student.getScore());
        }
        System.out.println("BST by name:");
        ArrayList<Student> nameList = sectionArrayList.get(currentSection).dumpNameSection();
        for (Student student : nameList) {
            System.out.println(student.getPid() + ", " + student.getFirstName() + " " + student.getLastName() +
                    ", score = " + student.getScore());
        }
        System.out.println("BST by score:");
        ArrayList<Student> scoreList = sectionArrayList.get(currentSection).dumpScoreSection();
        for (Student student : scoreList) {
            System.out.println(student.getPid() + ", " + student.getFirstName() + " " + student.getLastName() +
                    ", score = " + student.getScore());
        }
        System.out.println("Size = " + idList.size());
        currentStudent = null;
    }

    public void gradeSection()
    {
        sectionArrayList.get(currentSection).grade();
        System.out.println("grading completed");
        currentStudent = null;
    }

    public void statSection()
    {
        System.out.println("Statistics of section " + currentSection + ":");
        ArrayList<gradeInfo> info = sectionArrayList.get(currentSection).stat();
        for (gradeInfo i : info) {
            if (i.numberOfStudent > 0) {
                System.out.println(i.numberOfStudent + " students with grade " + i.grade);
            }
        }
        currentStudent = null;
    }

    public void listSection(String grade)
    {
        ArrayList<Student> list = sectionArrayList.get(currentSection).list(grade);
        System.out.println("Students with grade " + grade + " are:");
        for (Student student:list) {
            System.out.println(student.getPid() + ", " + student.getFirstName() + " " + student.getLastName() +
                    ", score = " + student.getScore() + ", grade = " + student.getGrade());
        }
        System.out.println("Found " + list.size() + " students");
        currentStudent = null;
    }

    public void findPairSection() {
        findPairSection(0);
    }

    public void findPairSection(int score)
    {
        ArrayList<String> list = sectionArrayList.get(currentSection).findPair(score);
        System.out.println("Students with score difference less than or equal " + score + ":");
        for (String str : list) {
            System.out.println(str);
        }
        System.out.println("found " + list.size() + " pairs");
        currentStudent = null;
    }

    public void mergeSection()
    {
        currentStudent = null;
        if (!sectionArrayList.get(currentSection).empty()) {
            System.out.println("Sections could only be merged to an empty section. Section " + currentSection + " is not empty.");
            return;
        }
        for (int i = 1; i < 21; i++) {
            if (!sectionArrayList.get(i).empty() && i != currentSection && !sectionArrayList.get(i).isMerged()) {
                ArrayList<Student> list = sectionArrayList.get(i).dumpPidSection();
                for (Student student:list) {
                    sectionArrayList.get(currentSection).insertStudent(student);
                }
            }
        }
        sectionArrayList.get(currentSection).setMerged();
        System.out.println("All sections merged at section " + currentSection);
    }

    public void clearCourseData() {
        sectionArrayList.clear();
        enrolledStudentBST.clear();
        currentStudent = null;
        for (int i = 0; i < 21; i++) {
            sectionArrayList.add(new Section(i));
        }
        System.out.println("All course data cleared.");
    }
}
