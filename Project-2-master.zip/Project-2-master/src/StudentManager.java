
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentManager {
    private int type = 0; // 0 is .csv
    // 1 is .data
    private File input;
    private BST<String, Student> students;

    public StudentManager(String input) {
        this.input = new File(input);
        this.students = new BST<String, Student>();
        if (input.isEmpty() || input == null) {
            return;
        }
        String[] tokens = input.split("\\.");
        if (tokens.length != 2) {
            return;
        }
        if (tokens[1].equals("csv")) {
            type = 0;
        }
        else {
            type = 1;
        }
    }


    public void loadStudentData() throws IOException {

        if (this.input == null) {
            return;
        }
        if (this.type == 0)// csv
        {
            Scanner s = null;
            try {
                s = new Scanner(this.input);
            }
            catch (FileNotFoundException e) {
                //System.out.println("Students file not found. Exiting...");
                System.exit(-1);
            }
            String line = null;
            while (s.hasNextLine()) {
                line = s.nextLine();
                if (line.length() == 0) {
                    continue;
                }
                String[] studentDetails = line.split("\\s*,\\s*");
                String pid = "";
                if (studentDetails[0].length() != 9) {
                    for (int i = 0; i < 9 - studentDetails[0].length(); i++) {
                        pid += "0";
                    }
                    pid = pid + studentDetails[0];

                }
                else {
                    pid = studentDetails[0];
                }
                Student temp = new Student(studentDetails[1].toLowerCase(), studentDetails[2].toLowerCase(), studentDetails[3].toLowerCase(), pid);
                this.students.insert(pid,temp);
            }
            s.close();
        }
        else {
            RandomAccessFile raf = null;
            try {
                raf = new RandomAccessFile(input, "r");
                byte[] header = new byte[10];
                raf.read(header); // VTSTUDENTS
                String str = new String(header);
                int studentSize = raf.readInt();
                String divider = "GOHOKIES";
                for (int i = 0; i < studentSize; i++) {
                    long pid = raf.readLong();
                    String strPID = Long.toString(pid);
                    for (int k = strPID.length(); k < 9; k++) {
                        strPID = "0" + strPID;
                    }
                    //System.out.print(pid);
                    String firstName;
                    String middleName;
                    String lastName;
                    byte temp = raf.readByte();
                    StringBuilder stringBuilder = new StringBuilder();
                    while ((char)temp != '$') {
                        stringBuilder.append((char)temp);
                        temp = raf.readByte();
                    }

                    firstName = stringBuilder.toString();
                    stringBuilder = new StringBuilder();
                    temp = raf.readByte();
                    while ((char)temp != '$') {
                        stringBuilder.append((char)temp);
                        temp = raf.readByte();
                    }
                    middleName = stringBuilder.toString();
                    // get last name
                    stringBuilder = new StringBuilder();
                    temp = raf.readByte();
                    while ((char)temp != '$') {
                        stringBuilder.append((char)temp);
                        temp = raf.readByte();
                    }
                    lastName = stringBuilder.toString();
                    Student temp2 = new Student(firstName.toLowerCase(),middleName.toLowerCase(),lastName.toLowerCase(),strPID);
                    this.students.insert(strPID,temp2);
                    for (int j = 0; j < 8; j++) {
                        if ((char)raf.readByte() != divider.getBytes()[j]) {
                            System.out.println("end of section indicator error");
                            System.exit(-1);
                        }
                    }
                }
                raf.close();
            }
            catch (FileNotFoundException e) {
                //System.out.println("Students file not found.  Exiting...");
                System.exit(-1);
            }
        }
        System.out.println(input.getName() + " successfully loaded");
    }

    public void saveStudentData(String filename) {
        System.out.println("Saved all Students data to " + filename);
        try {
            RandomAccessFile randomFile = new RandomAccessFile(filename, "rw");
            randomFile.write("VTSTUDENTS".getBytes());
            randomFile.writeInt(students.size());
            ArrayList<Student> list = students.inorderTraversal();
            for (int i = 0; i < students.size(); i++) {
                randomFile.writeLong(Long.parseLong(list.get(i).getPid()));
                String firstName = list.get(i).getFirstName() + "$";
                String middleName = list.get(i).getMiddleName() + "$";
                String lastName = list.get(i).getLastName() + "$";
                randomFile.write(firstName.getBytes());
                randomFile.write(middleName.getBytes());
                randomFile.write(lastName.getBytes());
                randomFile.write("GOHOKIES".getBytes());
            }
            randomFile.close();
        }
        catch (IOException e) {
            System.out.println(e);
            System.exit(-1);
        }

    }



    public BST<String,Student> getStudents() {
        return this.students;
    }
}
