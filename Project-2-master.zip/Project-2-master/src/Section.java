import java.util.ArrayList;

/**
 * @author Shangzheng Ji
 *
 */
public class Section {
    ////
    private int sectionnumber;
    private BST<String,Integer> pidBST;
    private BST<String, Integer> nameBST;
    private BST<Integer,Integer> scoreBST;
    private ArrayList<Student> studentArrayList;
    private boolean isMerged;

    /**
     * 
     */
    public Section(int num) {
        this.nameBST = new BST<>();
        this.pidBST = new BST<>();
        this.scoreBST = new BST<>();
        this.studentArrayList = new ArrayList<>();
        this.sectionnumber = num;
        isMerged = false;
    }

    public void insertStudent(Student student)
    {
        String name = student.getLastName() + " " + student.getFirstName();
        nameBST.insert(name, studentArrayList.size());
        pidBST.insert(student.getPid(), studentArrayList.size());
        scoreBST.insert(student.getScore(), studentArrayList.size());
        this.studentArrayList.add(student);
    }

    public void removeStudent(String pid) {
        int index = pidBST.find(pid);
        Student student = studentArrayList.get(index);
        String studentName = student.getLastName() + " " + student.getFirstName();
        int score = student.getScore();
        pidBST.remove(pid);
        ArrayList<bstInfo> tempList = new ArrayList<>();
        do {
            bstInfo info = new bstInfo();
            info.index = nameBST.remove(studentName);
            info.name = studentArrayList.get(info.index).getLastName() + " " + studentArrayList.get(info.index).getFirstName();
            if (index == info.index)
                break;
            tempList.add(info);
        }
        while (true);
        for (bstInfo info : tempList)
        {
            nameBST.insert(info.name, info.index);
        }
        tempList.clear();
        do {
            bstInfo info = new bstInfo();
            info.index = scoreBST.remove(student.getScore());
            info.score = studentArrayList.get(info.index).getScore();
            if (index == info.index)
                break;
            tempList.add(info);
        }
        while (true);
        for (bstInfo info : tempList)
        {
            scoreBST.insert(info.score, info.index);
        }
    }

    public void setStudentScore(String pid, int score)
    {
        Integer index = pidBST.find(pid);
        Student editStudent = studentArrayList.get(index);
        ArrayList<bstInfo> tempList = new ArrayList<>();
        do {
            bstInfo info = new bstInfo();
            info.index = scoreBST.remove(editStudent.getScore());
            info.score = studentArrayList.get(info.index).getScore();
            if (index.equals(info.index))
                break;
            tempList.add(info);
        }
        while (true);
        for (bstInfo info : tempList)
        {
            scoreBST.insert(info.score, info.index);
        }
        scoreBST.insert(score, index);
        studentArrayList.get(index).setScore(score);
    }

    public Student searchid(String pid)
    {
        Student student = null;
        Integer index = pidBST.find(pid);
        if (index != null)
        {
            student = studentArrayList.get(index);
        }
        return student;
    }

    public ArrayList<Student> search(String firstName, String lastName)
    {
        ArrayList<Student> list = new ArrayList<>();
        ArrayList<Integer> index = nameBST.inorderTraversal();
        if (index == null) {
            return list;
        }
        for(int i:index)
        {
            Student student = studentArrayList.get(i);
            if(student.getFirstName().equals(firstName) && student.getLastName().equals(lastName))
            {
                list.add(studentArrayList.get(i));
            }
        }
        return list;
    }

    public ArrayList<Student> search(String name)
    {
        ArrayList<Student> list = new ArrayList<>();
        ArrayList<Integer> index = nameBST.inorderTraversal();
        if (index == null) {
            return list;
        }
        for(int i:index)
        {
            Student student = studentArrayList.get(i);
            if(student.getFirstName().equals(name) || student.getLastName().equals(name))
            {
                list.add(studentArrayList.get(i));
            }
        }
        return list;
    }


    public void clear()
    {
        pidBST.clear();
        nameBST.clear();
        scoreBST.clear();
        studentArrayList.clear();
        isMerged = false;
    }

    public void setMerged()
    {
        isMerged = true;
    }

    public ArrayList<Student> dumpPidSection()
    {
        ArrayList<Student> list = new ArrayList<>();
        ArrayList<Integer> index = pidBST.inorderTraversal();
        if (index == null) {
            return list;
        }
        for (int i : index)
        {
            list.add(studentArrayList.get(i));
        }
        return list;
    }

    public ArrayList<Student> dumpNameSection()
    {
        ArrayList<Student> list = new ArrayList<>();
        ArrayList<Integer> index = nameBST.inorderTraversal();
        if (index == null) {
            return list;
        }
        for (int i : index)
        {
            list.add(studentArrayList.get(i));
        }
        return list;
    }

    public ArrayList<Student> dumpScoreSection()
    {
        ArrayList<Student> list = new ArrayList<>();
        ArrayList<Integer> index = scoreBST.inorderTraversal();
        if (index == null) {
            return list;
        }
        for (int i : index)
        {
            list.add(studentArrayList.get(i));
        }
        return list;
    }

    public void grade()
    {
        ArrayList<Integer> index = scoreBST.inorderTraversal();
        for (int i : index)
        {
            int score = studentArrayList.get(i).getScore();
            if (score < 50) {
                studentArrayList.get(i).setGrade("F ");
            }
            else if (score < 53) {
                studentArrayList.get(i).setGrade("D-");
            }
            else if (score < 55) {
                studentArrayList.get(i).setGrade("D ");
            }
            else if (score < 58) {
                studentArrayList.get(i).setGrade("D+");
            }
            else if (score < 60) {
                studentArrayList.get(i).setGrade("C-");
            }
            else if (score < 65) {
                studentArrayList.get(i).setGrade("C ");
            }
            else if (score < 70) {
                studentArrayList.get(i).setGrade("C+");
            }
            else if (score < 75) {
                studentArrayList.get(i).setGrade("B-");
            }
            else if (score < 80) {
                studentArrayList.get(i).setGrade("B ");
            }
            else if (score < 85) {
                studentArrayList.get(i).setGrade("B+");
            }
            else if (score < 90) {
                studentArrayList.get(i).setGrade("A-");
            }
            else {
                studentArrayList.get(i).setGrade("A ");
            }
        }
    }

    public ArrayList<gradeInfo> stat()
    {
        ArrayList<gradeInfo> list = new ArrayList<>();
        String[] grades = { "A ", "A-", "B+", "B ", "B-", "C+", "C ", "C-", "D+", "D ", "D-", "F " };
        for (String grade : grades)
        {
            ArrayList<Integer> index = pidBST.inorderTraversal();
            gradeInfo info = new gradeInfo();
            info.grade = grade;
            for (int i : index)
            {
                if (studentArrayList.get(i).getGrade().compareTo(grade) == 0)
                {
                    info.numberOfStudent++;
                }
            }
            list.add(info);
        }
        return list;
    }

    public ArrayList<Student> list(String grade)
    {
        ArrayList<Integer> index = pidBST.inorderTraversal();
        ArrayList<Student> list = new ArrayList<>();
        if (grade.contains("*"))
        {
            grade = grade.substring(0, grade.length() - 1);
            if (index != null) {
                for (int i : index)
                {
                    if (studentArrayList.get(i).getGrade().contains(grade))
                    {
                        list.add(studentArrayList.get(i));
                    }
                }
            }
        }
        else
        {
            if (index != null) {
                for (int i : index)
                {
                    if (studentArrayList.get(i).getGrade().trim().equals(grade))
                    {
                        list.add(studentArrayList.get(i));
                    }
                }
            }
        }
        return list;
    }

    public ArrayList<String> findPair(int score)
    {
        ArrayList<Integer> index = pidBST.inorderTraversal();
        ArrayList<String> list = new ArrayList<>();
        if (index == null) {
            return list;
        }
        for (int i : index)
        {
            Student student1 = studentArrayList.get(i);
            for (int j : index)
            {
                Student student2 = studentArrayList.get(j);
                String pair = student1.getFirstName() + " " + student1.getLastName() +
                        ", " + student2.getFirstName() + " " + student2.getLastName();
                String reversePair = student2.getFirstName() + " " + student2.getLastName() +
                        ", " + student1.getFirstName() + " " + student1.getLastName();
                if (Math.abs(student1.getScore() - student2.getScore()) <= score &&
                !list.contains(pair) && !list.contains(reversePair) &&
                !student1.equals(student2))
                {
                    list.add(pair);
                }
            }
        }
        return list;
    }

    public boolean empty()
    {
        return pidBST.size() == 0;
    }

    public boolean isMerged() {
        return isMerged;
    }

    public void notMerged() {
        isMerged = false;
    }

    public int getSize() {
        return pidBST.size();
    }


}

class gradeInfo
{
    protected String grade;
    protected int numberOfStudent;
}

class bstInfo
{
    protected String name;
    protected Integer score;
    protected Integer index;
}