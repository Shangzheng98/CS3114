import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Coursemanager2 {
    public static void main(String[] args) throws Exception {
        try {
            CourseManager courseManager = new CourseManager();
            StudentManager studentManager = null;
            File input = new File(args[0]);
            Scanner scanner = null;
            try {
                scanner = new Scanner(input);
            }
            catch (FileNotFoundException e) {
                System.out.println(e);
                System.exit(-1);
            }
            String line = null;
            while (scanner.hasNextLine()) {
                line = scanner.nextLine().trim();
                if (line.length() > 0) {
                    String[] command = line.split("\\s+");
                    if (command[0].equals("loadstudentdata")) {
                        studentManager = new StudentManager(command[1]);
                        try {
                            studentManager.loadStudentData();
                        }
                        catch (IOException e) {
                            System.out.println(e);
                            System.exit(-1);
                        }
                        courseManager.loadStudentManager(studentManager);
                    }
                    else if(command[0].equals("loadcoursedata")) {
                        try {
                            courseManager.loadCourseData(command[1]);
                        }
                        catch (IOException e) {
                            System.out.println(e);
                            System.exit(-1);
                        }
                    }
                    else if (command[0].equals("savestudentdata")) {
                        studentManager.saveStudentData(command[1]);
                    }
                    else if (command[0].equals("savecoursedata")) {
                        courseManager.saveCourseData(command[1]);
                    }

                    line = line.toLowerCase();
                    command = line.split("\\s+");
                    if (command[0].equals("section")) {
                        courseManager.setCurrentSection(Integer.parseInt(command[1]));
                    }
                    else if (command[0].equals("insert")) {
                        courseManager.insertStudent(command[1], command[2], command[3]);
                    }
                    else if (command[0].equals("searchid")) {
                        courseManager.searchStudentId(command[1]);
                    }
                    else if (command[0].equals("search")) {
                        if (command.length == 2) {
                            courseManager.searchStudent(command[1]);
                        }
                        else {
                            courseManager.searchStudent(command[1], command[2]);
                        }
                    }
                    else if (command[0].equals("score")) {
                        courseManager.scoreStudent(Integer.parseInt(command[1]));
                    }
                    else if (command[0].equals("remove")) {
                        if (command.length == 2) {
                            courseManager.removeStudent(command[1]);
                        }
                        else {
                            courseManager.removeStudent(command[1], command[2]);
                        }

                    }
                    else if (command[0].equals("clearsection")) {
                        courseManager.clearSection();
                    }
                    else if (command[0].equals("dumpsection")) {
                        courseManager.dumpSection();
                    }
                    else if (command[0].equals("grade")) {
                        courseManager.gradeSection();
                    }
                    else if (command[0].equals("stat")) {
                        courseManager.statSection();
                    }
                    else if (command[0].equals("list")) {
                        courseManager.listSection(command[1].toUpperCase());
                    }
                    else if (command[0].equals("findpair")) {
                        if (command.length == 1) {
                            courseManager.findPairSection();
                        }
                        else {
                            courseManager.findPairSection(Integer.parseInt(command[1]));
                        }
                    }
                    else if (command[0].equals("merge")) {
                        courseManager.mergeSection();
                    }
                    else if (command[0].equals("clearcoursedata")) {
                        courseManager.clearCourseData();
                    }
                }
            }

        }
        catch (Exception e) {
            StackTraceElement[] errorList = e.getStackTrace();
            String error = null;
            for(StackTraceElement element:errorList) {
                error = error + "Class Name: " + element.getClassName() + "\n";
                error = error + "Method Name: " + element.getMethodName() + "\n";
                error = error + "Line number: " + element.getLineNumber() + "\n";
            }
            throw new Exception(error);
        }
    }
}
