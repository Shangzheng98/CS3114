import java.io.IOException;

public class SectionTest extends student.TestCase{
	private Section s1;
	private StudentManager sm;
	public void setUp()
	{
		sm = new StudentManager("students.data");
		s1 = new Section(1);
	}

	public void test()
	{
		try {
			sm.loadStudentData();
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		Student student1 = new Student("091199111", "sss", "", "ldds","C", 90);
		Student s2 = new Student("091199112", "sssdsads", "", "lqqs","C", 80);
		Student s3 = new Student("091199113", "sssdsds", "", "lccs","C", 70);
		Student s4 = new Student("091199114", "sssfddsd", "", "lsdd","C", 80);
		Student s5 = new Student("091199115", "sss", "", "ls","C", 80);
		s1.insertStudent(student1);
		s1.insertStudent(s2);
		s1.insertStudent(s3);
		s1.insertStudent(s4);
		s1.insertStudent(s5);
		s1.dumpNameSection();

	}



}