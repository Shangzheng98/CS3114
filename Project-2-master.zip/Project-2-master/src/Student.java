/**
 * @author Shangzheng Ji
 * @author Ruichang Chen
 */
public class Student {
    private String firstName;
    private String middleName;
    private String lastName;
    private String grade;
    private String pid;
    private int score;
    private boolean isRemoved;
    /**
     * 
     * @param fstName
     * @param middleName
     * @param lastName
     * @param pid
     */
    public Student(String fstName, String middleName, String lastName, String pid)
    {
        this.firstName = fstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.pid = pid;
        this.score = 0;
        this.grade = "F ";
    }

    public Student(String fstName, String middleName, String lastName, String pid, String grade, int score)
    {
        this.firstName = fstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.pid = pid;
        this.score = score;
        this.grade = grade;
    }
    
    public String getFirstName()
    {
        return this.firstName;
    }
    public String getMiddleName()
    {
        return this.middleName;
    }
    public String getLastName()
    {
        return this.lastName;
    }
    public String getPid() { return this.pid; }
    public void setFirstName(String newName)
    {
        this.firstName = newName;
    }
    public void setMiddleName(String newName)
    {
        this.middleName = newName;
    }
    public void setLastName(String newName)
    {
        this.lastName = newName;
    }
    public void setPid(String newPid)
    {
        this.pid = newPid;
    }
    public int getScore()
    {
        return this.score;
    }
    public String getGrade()
    {
        return this.grade;
    }
    public void setScore(int newScore)
    {
        this.score = newScore;
    }
    public void setGrade(String newGrade)
    {
        this.grade = newGrade;
    }
    public void remove() {this.isRemoved = true;}
}