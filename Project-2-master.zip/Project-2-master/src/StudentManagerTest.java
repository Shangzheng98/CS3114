import java.io.IOException;
import java.util.ArrayList;

public class StudentManagerTest extends student.TestCase{
    private StudentManager studentManager;
    public void setUp(){

    }

    public void test() throws IOException {
        studentManager = new StudentManager("ji_SMTest.csv");
        studentManager.loadStudentData();
        ArrayList<Student> list = studentManager.getStudents().inorderTraversal();
        for (Student student : list) {
            System.out.println(student.getFirstName() + " " + student.getLastName() + " " +
                    student.getPid() + " " + student.getScore() + " " + student.getGrade());
        }
        studentManager.saveStudentData("ji_SMTest.data");
        studentManager = new StudentManager("ji_SMTest.data");
        studentManager.loadStudentData();
        list = studentManager.getStudents().inorderTraversal();
        for (Student student : list) {
            System.out.println(student.getFirstName() + " " + student.getLastName() + " " +
                    student.getPid() + " " + student.getScore() + " " + student.getGrade());
        }
    }
}
