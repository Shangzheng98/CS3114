
import java.util.*;

/**
 * this class is a generic class of BST
 * 
 * @author Shangzheng Ji
 * @author Ruichang Chen
 * @version 09/23/2019
 * @param <K>
 *            the key in the BST
 * @param <V>
 *            the value in the BST
 * 
 */
public class BST<K extends Comparable<K>, V> implements Iterable<V> {
    private BSTNode<K, V> root;
    private int nodecount;


    /**
     * Default constructor for BST
     */
    public BST() {
        root = null;
        this.nodecount = 0;

    }


    /**
     * Constructor for iterator
     */
    @Override
    public Iterator<V> iterator() {

        return new BSTIterator();

    }


    /**
     * Clear BST
     */
    public void clear() {
        root = null;
        this.nodecount = 0;
    }


    /**
     * Find value according to the key
     * 
     * @param key
     *            key value for the node
     * @return corresponding value
     */
    public V find(K key) {
        return findHelp(this.root, key);
    }


    /**
     * Check if a node is present in the BST
     * 
     * @param key
     *            key value of the node
     * @return true if present
     */
    public boolean contain(K key) {
        return this.containHelp(root, key) != null;
    }


    /**
     * Helper function for contain
     * 
     * @param rt
     *            a node of BST
     * @param key
     *            key value in the node
     * @return value of the node corresponding to the key
     */
    private V containHelp(BSTNode<K, V> rt, K key) {
        if (rt == null) {
            return null;
        }
        if (rt.getKey().compareTo(key) > 0) {
            return findHelp(rt.getLeft(), key);
        }
        else if (rt.getKey().compareTo(key) == 0) {
            return rt.getValue();
        }
        else {
            return findHelp(rt.getRight(), key);
        }
    }


    /**
     * Helper function for find
     * 
     * @param rt
     *            a node of BST
     * @param key
     *            key value in the node
     * @return value of the node corresponding to the key
     */
    private V findHelp(BSTNode<K, V> rt, K key) {
        if (rt == null) {
            return null;
        }
        if (rt.getKey().compareTo(key) > 0) {
            return findHelp(rt.getLeft(), key);
        }
        else if (rt.getKey().compareTo(key) == 0) {
            return rt.getValue();
        }
        else {
            return findHelp(rt.getRight(), key);
        }
    }




    /**
     * Insert a new node into BST
     * 
     * @param key
     *            key value of the node
     * @param value
     *            value of the node
     */
    public void insert(K key, V value) {
        root = inserthelp(root, key, value);
        nodecount++;
    }


    /**
     * Helper function for insert
     * 
     * @param rt
     *            a node of BST
     * @param key
     *            key value in the node
     * @param value
     *            value of the node corresponding to the key
     * @return new node inserted into the BST
     */
    private BSTNode<K, V> inserthelp(BSTNode<K, V> rt, K key, V value) {
        if (rt == null) {
            return new BSTNode<K, V>(key, value);
        }
        if (rt.getKey().compareTo(key) > 0) {
            rt.setLeft(inserthelp(rt.getLeft(), key, value));
        }
        else {
            rt.setRight(inserthelp(rt.getRight(), key, value));
        }
        return rt;
    }


    /**
     * Helper function for remove
     * 
     * @param rt
     *            a node of BST
     * @return the minimum node under the node
     */
    private BSTNode<K, V> getMin(BSTNode<K, V> rt) {
        if (rt.getLeft() == null) {
            return rt;
        }
        else {
            return getMin(rt.getLeft());
        }
    }


    /**
     * Remove the minimum node under a specific node
     * 
     * @param rt
     *            a node of BST
     * @return the node being removed
     */
    private BSTNode<K, V> deleteMin(BSTNode<K, V> rt) {
        if (rt.getLeft() == null) {
            return rt.getRight();
        }
        rt.setLeft(deleteMin(rt.getLeft()));
        return rt;
    }


    /**
     * Remove a node in BST
     * 
     * @param key
     *            key value of the node needed be removed
     * @return the node being removed
     */
    public V remove(K key) {
        V temp = findHelp(root, key);
        if (temp != null) {
            this.root = removeHelp(root, key);
            this.nodecount--;
        }
        return temp;
    }


    /**
     * Helper function for remove a node
     * 
     * @param rt
     *            a node in BST
     * @param key
     *            key value of the node to be remove
     * @return the node being removed
     */
    private BSTNode<K, V> removeHelp(BSTNode<K, V> rt, K key) {
        if (rt.getKey().compareTo(key) > 0) {
            rt.setLeft(removeHelp(rt.getLeft(), key));
        }
        else if (rt.getKey().compareTo(key) < 0) {
            rt.setRight(removeHelp(rt.getRight(), key));
        }
        else {
            if (rt.getLeft() == null) {
                return rt.getRight();
            }
            else if (rt.getRight() == null) {
                return rt.getLeft();
            }
            else {
                BSTNode<K, V> temp = getMin(rt.right);
                rt.setValue(temp.getValue());
                rt.setKey(temp.getKey());
                rt.setRight(deleteMin(rt.getRight()));
            }
        }
        return rt;
    }


    /**
     * In-order traversal of the BST
     * 
     * @return an ArrayList of node in in-order traversal order
     */
    public ArrayList<V> inorderTraversal() {
        ArrayList<V> list = new ArrayList<V>();
        BSTNode<K, V> current;
        BSTNode<K, V> pre;

        if (root == null) {
            return null;
        }

        current = this.root;
        while (current != null) {
            if (current.left == null) {
                // System.out.print(current.value+ " ");
                list.add(current.value);
                current = current.right;
            }
            else {
                pre = current.left;
                while (pre.right != null && pre.right != current) {
                    pre = pre.right;
                }
                if (pre.right == null) {
                    pre.right = current;
                    current = current.left;
                }
                else {
                    pre.right = null;
                    // System.out.print(current.value + " ");
                    list.add(current.value);
                    current = current.right;
                }

            }

        }
        return list;
    }


    /**
     * get the size of the BST
     * 
     * @return size of BST
     */
    public int size() {
        return this.nodecount;
    }


    /**
     * get root node of BST
     * 
     * @return root node of BST
     */
    public BSTNode<K, V> getRoot() {
        return this.root;
    }


    /**
     * A private generic class of the node in BST
     * 
     * @author Shangzheng Ji
     * @author Ruichang Chen
     * @param <K>
     *            key type
     * @param <V>
     *            value type
     */
    private class BSTNode<K, V> {

        private K key;
        private V value;
        private BSTNode<K, V> left;
        private BSTNode<K, V> right;


        /**
         * constructor of node
         * 
         * @param k
         *            key value of node
         * @param val
         *            value of node
         */
        public BSTNode(K k, V val) {
            left = null;
            right = null;
            key = k;
            value = val;
        }


        /**
         * get key of the node
         * 
         * @return key of the node
         */
        public K getKey() {
            return this.key;
        }


        /**
         * Set key value for the node
         * 
         * @param key
         *            key value to be set
         */
        public void setKey(K key) {
            this.key = key;
        }


        /**
         * get value of the node
         * 
         * @return value of the node
         */
        public V getValue() {
            return this.value;
        }


        /**
         * set value for the node
         * 
         * @param val
         *            value to be set in the node
         */
        public void setValue(V val) {
            this.value = val;
        }


        /**
         * get left node of this node
         * 
         * @return left node of the node
         */
        public BSTNode<K, V> getLeft() {
            return left;
        }


        /**
         * set left node of the node
         * 
         * @param left
         *            node to be set
         */
        public void setLeft(BSTNode<K, V> left) {
            this.left = left;
        }


        /**
         * get right node of this node
         * 
         * @return right node
         */
        public BSTNode<K, V> getRight() {
            return right;
        }


        /**
         * set right node of this node
         * 
         * @param right
         *            node to be set
         */
        public void setRight(BSTNode<K, V> right) {
            this.right = right;
        }

    }


    /**
     * Iterator class for BST
     * 
     * @author Shangzheng Ji
     * @author Ruichang Chen
     */
    private class BSTIterator implements Iterator<V> {
        private Stack<BSTNode<K, V>> stack = new Stack<BSTNode<K, V>>();


        /**
         * Default constructor for BST Iterator
         */
        public BSTIterator() {
            this.pushToStack(root);
        }


        /**
         * check if have next entry
         * 
         * @return true if have next entry
         */
        @Override
        public boolean hasNext() {
            return !stack.isEmpty();

        }


        /**
         * get next entry
         * 
         * @return next entry
         */
        @Override
        public V next() {
            BSTNode<K, V> next = stack.pop();
            pushToStack(next.right);
            return next.value;
        }


        /**
         * push a item to stack
         * 
         * @param node
         *            a node in BST
         */
        private void pushToStack(BSTNode<K, V> node) {
            while (node != null) {
                 stack.push(node);
                 node = node.left;
            }
        }

    }
}


