public class Studentmanager {
     public static void main(String[] args) {

    }
}
